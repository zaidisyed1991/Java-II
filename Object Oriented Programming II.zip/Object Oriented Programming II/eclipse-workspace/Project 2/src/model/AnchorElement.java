package model;

public class AnchorElement extends TagElement {
    private String url;
    private String linkText;
    String attributes;

    public AnchorElement(String url, String linkText, String attributes){
        super("a", true, new TextElement(linkText), "href=" + "\"" + url + "\"" + decideContent(attributes));
        this.url = url;
        this.linkText = linkText;
        this.attributes = attributes;

    }

    private static String decideContent(String attributes) {

        if(attributes == null) {
            return "";
        }
        return attributes;
    }

    @Override
    public String genHTML(int indentation){
        /*
         * 1.) Create an empty string
         * 2.) make a for loop with the check condition to go to indentation as limit
         * 3.) within body of loop concatenate string with indentation (i.e. " ")
         * 4.) Concatenate string with genHTML.
         * 5.) concatenate string with new line
         *    <a href="http://www.cs.umd.edu">UMD</a>
         */
        String anchorElement = "";
        for (int i = 0; i < indentation; i++) {
            anchorElement += " ";
        }
        anchorElement += super.genHTML(0);

        return anchorElement;
    }

    public String getUrlText(){
        return url;
    }
    public String getLinkText(){
        return linkText;
    }

}