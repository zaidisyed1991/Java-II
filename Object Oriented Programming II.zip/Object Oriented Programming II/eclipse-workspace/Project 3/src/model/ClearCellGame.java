package model;

import java.util.Arrays;
import java.util.Random;

/* This class must extend Game */
public class ClearCellGame extends Game  {
	/*shifted down one
	 * 
RRGYY   [ 0][0]       [0] [1]
RYBYR     [1] [0]     [1] [1]
.....      [2] [0]    [2] [1]
.....      [3] [0]   [3] [1]

              for( int i = 0; i < array.length ; i++){  i=0   4   i=1
                  =  array[array.length-1][i]     
               }

               ________________________________

               boardcell [][];
               or( int i = 0; i < existingarray.length ; i++){
               boardcell = existingarray[exisitngarray.length-2][i];

                }


.....		
RRGYY
RYBYR
.....

	 * 
	 *  shift down :
	 * 
	 *  copy all of  the elements excluding the last 
	 *  to the next row  
	 *  reset the first row
	 *  
	 * 
	 *  
	 *  and then iterate through the new empty top row and 
	 * put in random board cells
	 */
	int strategy;
	Random random;
	int score;
	BoardCell board;
	public ClearCellGame(int maxRows, int maxCols, Random random, int strategy){
		super(maxRows, maxCols);
		this.random = random;
		this.strategy = strategy;
		for( int row = 0 ; row < super.board.length; row++) { 
			for (int col = 0; col < super.board[row].length; col++) {
				super.board[row][col] = BoardCell.EMPTY;
			}
		}


		//this.board = board.EMPTY;
	}
	public void nextAnimationStep() {
		/*  
		 * RRGYY
RYBYR
.....
.....

		 */
		boolean emptyLastRow = true;
		//{{1,2,3}, { ...} , {7,8,9}}    =  {{ , {7,8,9} { ....}}
		//2d array instantiate
		for(int col = 0 ; col < super.board[super.board.length-1].length; col++ ) {
			 if(super.board[super.board.length -1 ][col] != BoardCell.EMPTY) {
				 emptyLastRow = false;
			 }
		}
		if(isGameOver() == false) {
			BoardCell [][] temp = new BoardCell [super.board.length][] ;
			for(int row = 0 ; row < super.board.length; row++) {
				temp[row] = new BoardCell [super.board[row].length];
			}
			for( int row = 0 ; row < super.board.length; row++) { 
				for (int col = 0; col < super.board[row].length; col++) {
					temp[row][col] = super.board[row][col];
				}
			}
			System.out.println(Arrays.deepToString(super.board));
		
			for( int row = 0 ; row < super.board.length-1; row++) { 
				for (int col = 0; col < super.board[row].length; col++) {
					super.board[row+1][col]  = temp[row][col];
				}
			}

		
			for(int row = 0 ; row < super.board.length; row++) {
				for (int col = 0; col < super.board[row].length; col++) {
					if(super.board[row][col] == null) {
						super.board[row][col] = BoardCell.EMPTY;
					}
				}
		
			}
			for(int col = 0; col < super.board[0].length; col++) {
				super.board[0][col] = BoardCell.getNonEmptyRandomBoardCell(random);
			}

		}

	}
	@Override
	public boolean isGameOver() {
		// TODO Auto-generated method stub

		/*
		 the game is over if any 
		 of the elements in the last row is not empty.
		  we create an  loop that travereses the rows
		  of the  2d array, within the body of the 
		   loop we make an if condition that checks
		    if the last row (last row means array.lenght) 
		    is NOT EQUAL TO (!=) null.
		  within the body of the if statement we return true;
		  out side everything before the method ends 
		  with return false
		 */
		//{{1,2,3}, { 4, 5, 6} , {7,8,9}}

		for (int i = 0; i < super.board[super.board.length-1].length; i++) {
			if (super.board[super.board.length-1][i] !=  BoardCell.EMPTY) {
				return true;
			}

		}


		return false;
	}
	@Override
	public int getScore() {
		// TODO Auto-generated method stub
		return score;
	}

	public void collapse(int rowIndex) {   
		//{{1,2,3}, { ...} , {7,8,9}}    =  {{ , {7,8,9} { ....}}
		//2d array instantiate
		BoardCell [][] temp = new BoardCell [super.board.length][] ;
		for(int row = 0 ; row < super.board.length; row++) {
			temp[row] = new BoardCell [super.board[row].length];
		}
		for( int row = rowIndex+1 ; row < super.board.length; row++) { 
			for (int col = 0; col < super.board[row].length; col++) {
				temp[row-1][col] = super.board[row][col];
			}
		}

		/*System.out.println("this is before we collapse");
			printBoard(super.board);*/
		for( int row = rowIndex ; row < super.board.length; row++ ) {
			for (int col = 0; col < super.board[row].length; col++) {
				super.board[row][col] = temp[row][col];
			}
		}


		for(int row = 0 ; row < super.board.length; row++) {
			for (int col = 0; col < super.board[row].length; col++) {
				if(super.board[row][col] == null) {
					super.board[row][col] = BoardCell.EMPTY;
				}
			}

		}

	}


	private void checkNeedsCollapse() {
		// helps  to check if the row is entierly white 
		// it does this by comapring itself to the length of the row 
		int count = 0;
		int cellNeedsCollapse = 0;

		for( int row = 0 ; row < super.board.length; row++) {
			for( int col = 0 ; col < super.board[row].length; col++){
				if(super.board[row][col] == BoardCell.EMPTY) {
					count++;
				} 
			}

			if( count == super.board[row].length) {
				collapse(row);	
				break;

			} 
			count = 0;
		}
	}

	private void clearHorizontal(BoardCell colorCell, int rowIndex, int colIndex ) {	
		//(1,4):   (1,3) (1,2) (1,1) (1,0)
		System.out.println("before left");
		printBoard(super.board);
		BoardCell crntColorCell = null;
		for( int col = colIndex-1 ; col >= 0 ; col --){
			crntColorCell = super.board[rowIndex][col];
			if(crntColorCell == colorCell){
				super.board[rowIndex][col] = BoardCell.EMPTY;
				score++;
			} else{
				break;
			}
		}
	


		for( int col = colIndex + 1 ; col < super.board[rowIndex].length ; col ++){
			crntColorCell =  super.board[rowIndex][col];;
			if(crntColorCell == colorCell){
				super.board[rowIndex][col] = BoardCell.EMPTY;
				score++;
			} else{
				break;
			}
		}
		System.out.println("after right");
		printBoard(super.board);



	}

	private void clearVertical(BoardCell colorCell, int rowIndex, int colIndex ) {	
		BoardCell crntColorCell = null;
		for( int row = rowIndex-1 ; row >= 0 ; row --){
			crntColorCell =  super.board[row][colIndex];
			if(crntColorCell == colorCell){
				super.board[row][colIndex] = BoardCell.EMPTY;
				score++;
			} else {
				break;
			}
		}
		System.out.println("print after going up");
		printBoard(super.board);
		for (int row = rowIndex+1; row < super.board.length; row++) {
			crntColorCell =  super.board[row][colIndex];
			if(crntColorCell == colorCell){
				super.board[row][colIndex] = BoardCell.EMPTY;
				score++;
			} else {
				break;
			}
		}

		System.out.println("print after going down");

		printBoard(super.board);

		//checkNeedsCollapse();
	}


	/* [ 3  6, 6,  7]           
	 * [ 5  3  6 , 8]
	 * [ 1  2  3 , 9]     
	 * [ 1  4  5.  6] 
	 */     
	// (1,4):   (1,5) (1,6) (1,7) (1,8)     
	// { {3, 6, 6,7} |, { 5 ,3, 6,8 },| { 1  2 3 ,9} , | { 1, 4 ,5,6}  


	private void clearDiagonal(BoardCell colorCell, int rowIndex, int colIndex ) {

		//go southEast


		BoardCell crntColorCell = null;
		int col = colIndex+1;
		boolean sameAsParent = true;
		for(int row = rowIndex + 1 ; row < super.board.length; row++) {
			while(col < super.board[row].length) {
				crntColorCell = super.board[row][col];
				if(crntColorCell == colorCell) {
					super.board[row][col] = BoardCell.EMPTY;
					score++;
				} else {
					sameAsParent = false;
					break;
				}
				col++;
				break;
			}
			if(!sameAsParent) {
				break;
			}
		}



		//soUTHWEST
		sameAsParent = true;
		col = colIndex-1;
		for(int row = rowIndex + 1 ; row < super.board.length; row++) {
			while(col >= 0) {
				crntColorCell = super.board[row][col];
				if(crntColorCell == colorCell) {
					super.board[row][col] = BoardCell.EMPTY;
					score++;
				} else {
					sameAsParent = false;
					break;
				}
				col--;
				break;
			}
			if(!sameAsParent) {
				break;
			}
		}

	

		//NorthEast
		
		col = colIndex+1;
		for (int row = rowIndex-1; row >= 0; row--) {
			while(col < super.board[row].length){
				crntColorCell = super.board[row][col];
				if(crntColorCell == colorCell) {
					super.board[row][col] = BoardCell.EMPTY;
					score++;
				} else {
					sameAsParent = false;
					break;
				}
				col++;
				break;
			}
			if(!sameAsParent) {
				break;
			}

		}
	


		//northwest

		col = colIndex-1;
		for (int row = rowIndex-1; row >= 0; row--) {
			while(col >= 0){
				crntColorCell = super.board[row][col];
				if(crntColorCell == colorCell) {
					super.board[row][col] = BoardCell.EMPTY;
					score++;
				} else {
					sameAsParent = false;
					break;
				}
				col--;
				break;
			}
			if(!sameAsParent) {
				break;
			}

		}
		

	}


   private boolean  isEmpty() {
	   for(int row = 0 ; row < super.board.length ; row ++) {
		   for( int col = 0 ; col < super.board[row].length ; col++) {
			   if (super.board[row][col] !=  BoardCell.EMPTY) {
					return false;
				}
		   }
	   }
	   return true;
   }
   private boolean firstRowIsEmpty() {
	   for( int col = 0 ; col < super.board[0].length ; col++) {
		   if (super.board[0][col] !=  BoardCell.EMPTY) {
			  return false;
		   }
	   }
	   return true;
   }
	@Override
	public void processCell(int rowIndex, int colIndex) {
		// TODO Auto-generated method stub
		boolean firstRowE = false;
		boolean boardE = false;
		if(rowIndex <= super.board.length && colIndex <= super.board[0].length
				&& rowIndex >=0 && colIndex >=0) {
			BoardCell colorCell = super.board[rowIndex][colIndex];
			if(colorCell != BoardCell.EMPTY) {
				super.board[rowIndex][colIndex] = BoardCell.EMPTY;
				score++;
				System.out.println("current");
				printBoard(super.board);
				clearHorizontal(colorCell, rowIndex, colIndex);
				clearVertical(colorCell, rowIndex, colIndex);
				clearDiagonal(colorCell, rowIndex, colIndex);
				checkNeedsCollapse();
				firstRowE =  firstRowIsEmpty();
				boardE = isEmpty();
				while(firstRowE == true && boardE == false) {
					
					checkNeedsCollapse();
					firstRowE =  firstRowIsEmpty();
					boardE = isEmpty();
					
				}
				
			}
		}
	}

	private static String getBoardStr(Game game) {

		int maxRows = game.getMaxRows(), maxCols = game.getMaxCols();

		String answer = "Board(Rows: " + maxRows + ", Columns: " + maxCols + ")\n";
		for (int row = 0; row < maxRows; row++) {
			for (int col = 0; col < maxCols; col++) {
				answer += game.getBoardCell(row, col).getName();
			}
			answer += "\n";
		}

		return answer;
	}
	private static void printBoard(BoardCell[][] board){
		int maxRows = board.length, maxCols = board[0].length;
		String answer = "Board(Rows: " + maxRows + ", Columns: " + maxCols + ")\n";
		for (int row = 0; row < maxRows; row++) {
			for (int col = 0; col < maxCols; col++) {
				answer += board[row][col].getName();
			}
			answer += "\n";
		}
		System.out.println(answer);

	}

}