package blackjack;
import java.util.*;

public class Blackjack implements BlackjackEngine {
	private int numberOfDecks;
	private int accountAmount;
	private int betAmount;
	private int gameStatus;
	private ArrayList<Card> playerCards;
	private ArrayList<Card> dealerCards;
	private ArrayList<Card> gameDeck;
	private Random randomGenerator;

	/**
	 * Constructor you must provide.  Initializes the player's account 
	 * to 200 and the initial bet to 5.  Feel free to initialize any other
	 * fields. Keep in mind that the constructor does not define the 
	 * deck(s) of cards.
	 * @param randomGenerator
	 * @param numberOfDecks
	 */
	public Blackjack(Random randomGenerator, int numberOfDecks) {
		this.randomGenerator = randomGenerator;
		this.numberOfDecks = numberOfDecks;
		betAmount = 5;
		accountAmount = 200;

		playerCards = new ArrayList<Card>();
		dealerCards = new ArrayList<Card>();
		gameDeck = new ArrayList<Card>();
		
		//initializing the game (technically it's in progress)
		gameStatus = GAME_IN_PROGRESS;
	}

	public int getNumberOfDecks() {
		return numberOfDecks;
	}

	public void createAndShuffleGameDeck() {
		
		//In order to create new deck we need to clear it first if it is not empty
		gameDeck.clear();
		//For each deck, we are going to go add all 52 cards
		for (int currentDeckNum = 0; currentDeckNum < numberOfDecks; currentDeckNum++) {
			for (CardSuit suit : CardSuit.values()) {
				for (CardValue value : CardValue.values()) {
					gameDeck.add(new Card(value, suit));
				}
			}
		}
		Collections.shuffle(gameDeck, randomGenerator);	
	}

	public Card[] getGameDeck() {
		Card[] gameDeckArray = new Card[gameDeck.size()];
		for (int i = 0; i < gameDeck.size(); i++) {
			gameDeckArray[i] = gameDeck.get(i);
		}
		return gameDeckArray;
	}

	public void deal() {
		//•	When a new game is dealt the bet amount is deducted from the account.
		accountAmount -= betAmount;
		
		gameStatus = GAME_IN_PROGRESS;


		playerCards.clear();
		dealerCards.clear();
		
		//Creates new deck(s) of cards and shuffles them; assigns cards to the dealer and player.
		createAndShuffleGameDeck();

		// Give to cards to player and dealer
		// [a,b,c,d,e] cards [a,c] goes to player and [b,d] to dealer
		for (int i = 0; i < 2; i++) {
			Card playerCard = gameDeck.remove(0);
			playerCards.add(playerCard);
			Card dealerCard = gameDeck.remove(0);
			dealerCards.add(dealerCard);
		}
		
		//we are setting dealer 2nd card to face down
		dealerCards.get(0).setFaceDown();
	}

	public Card[] getDealerCards() {
		Card[] dealerCardArray = new Card[dealerCards.size()];
		for (int i = 0; i < dealerCards.size(); i++) {
			dealerCardArray[i] = dealerCards.get(i);
		}
		return dealerCardArray;
	}
	
	public int[] getDealerCardsTotal() {
		return getCardsTotal(dealerCards);
	}

	public int getDealerCardsEvaluation() {
		return getCardsEvaluation(dealerCards);
	}

	public Card[] getPlayerCards() {
		Card[] playerCardsArray = new Card[playerCards.size()];
		for (int i = 0; i < playerCards.size(); i++) {
			playerCardsArray[i] = playerCards.get(i);
		}
		return playerCardsArray;
	}

	public int[] getPlayerCardsTotal() {
		return getCardsTotal(playerCards);
	}

	public int getPlayerCardsEvaluation() {
		return getCardsEvaluation(playerCards);
	}

	public void playerHit() {
		/*
		 * Retrieves a card from the deck and assigns the card to the player. The new sets of 
		 * cards will be evaluated. If the player busts, the game is over and the games's status 
		 * will be updated to DEALER_WON. Otherwise the game's status is GAME_IN_PROGRESS.
		 */
		
		Card card = gameDeck.remove(0);
		playerCards.add(card);
		
		int playerCardsEvaluation = getPlayerCardsEvaluation();
		if (playerCardsEvaluation == BUST) {
			gameStatus = DEALER_WON;
		} else {
			gameStatus = GAME_IN_PROGRESS;
		}
	}

	public void playerStand() {

		/*
		 * Flips the dealer's card that is currently face down and assigns cards to the 
		 * dealer as long as the dealer doesn't bust and the cards have a value less than 16. 
		 * Once the dealer has a hand with a value greater than or equal to 16, and less than or 
		 * equal to 21, the hand will be compared against the player's hand and whoever has the hand 
		 * with a highest value will win the game. If both have the same value we have a draw. The game's 
		 * status will be updated to one of the following values: DEALER_WON, PLAYER_WON, or DRAW. The player's 
		 * account will be updated with a value corresponding to twice the bet amount if the player wins. If there 
		 * is a draw the player's account will be updated with the only the bet amount.
		 */
		
		// inside deal function, we made the second card face down
		dealerCards.get(0).setFaceUp();
		
		//these values are <= 21
		int[] possibleDealerSums = getDealerCardsTotal(); //this could be length 2
		
		if (possibleDealerSums == null) {
			//dealerSum values > 21
			gameStatus = PLAYER_WON;
			accountAmount += (2 * betAmount);
		} else {
			int dealerSum;
			
			if (possibleDealerSums.length == 2) {
				int largerSum = possibleDealerSums[1];
				
				if (largerSum >= 16 && largerSum <=21) {
					dealerSum = largerSum;
				} else {
					while (largerSum < 16) {
						Card card = gameDeck.remove(0);
						dealerCards.add(card);
						int cardValue = card.getValue().getIntValue();
						
						largerSum += cardValue;	
						if (cardValue == 1) {
							if (largerSum + 10 <= 21) {
								largerSum += 10;
							}
						}

					}
					dealerSum = largerSum;
				}	
			} else {
				//size 1 case
				dealerSum = getDealerCardsTotal()[0];
				
				while (dealerSum < 16) {
					Card card = gameDeck.remove(0);
					dealerCards.add(card);
					int cardValue = card.getValue().getIntValue();
					
					dealerSum += cardValue;
					// if ace, we will try to see if we can take into account "11"
					if (cardValue == 1) {
						if (dealerSum + 10 <= 21) {
							dealerSum += 10;
						}
					}
				}
			}
			
			int dealerCardsEvaluation = getDealerCardsEvaluation();
			int playerCardsEvaluation = getPlayerCardsEvaluation();
			
		/*	if (dealerCardsEvaluation == BUST && playerCardsEvaluation == BUST) {
				gameStatus = DEALER_WON;
			} else*/
				
				
			if (dealerCardsEvaluation == BUST && playerCardsEvaluation != BUST) {
				gameStatus = PLAYER_WON;
				accountAmount += (2 * betAmount);
			} else if (dealerCardsEvaluation != BUST && playerCardsEvaluation == BUST) {
				gameStatus = DEALER_WON;
			} else if (dealerCardsEvaluation == BLACKJACK && playerCardsEvaluation != BLACKJACK) {
				gameStatus = DEALER_WON;
			} else if (dealerCardsEvaluation != BLACKJACK && playerCardsEvaluation == BLACKJACK) {
				gameStatus = PLAYER_WON;
				accountAmount += (2 * betAmount);
			} else if (dealerCardsEvaluation == BLACKJACK && playerCardsEvaluation == BLACKJACK) {
				gameStatus = DRAW;
				accountAmount += betAmount;
			} else if (dealerCardsEvaluation == HAS_21 && playerCardsEvaluation == HAS_21) {
				gameStatus = DRAW;
				accountAmount += betAmount;
			} else if (dealerCardsEvaluation == HAS_21 && playerCardsEvaluation != HAS_21) {
				gameStatus = DEALER_WON;
			} else if (dealerCardsEvaluation != HAS_21 && playerCardsEvaluation == HAS_21) {
				gameStatus = PLAYER_WON;
				accountAmount += (2 * betAmount);
			} else {
				//dealer and player did not bust or blackjack or has 21
				
				int playerSum;
				int[] possiblePlayerValues = getPlayerCardsTotal();
				if (possiblePlayerValues.length == 1) {
					playerSum = possiblePlayerValues[0];
				} else {
					playerSum = possiblePlayerValues[1];
				}

				if (playerSum != dealerSum) {
					gameStatus = (playerSum > dealerSum) ? PLAYER_WON : DEALER_WON;
					if (gameStatus == PLAYER_WON) {
						accountAmount += (2 * betAmount);
					}
				} else {
					gameStatus = DRAW;
					accountAmount += betAmount;
				}
			}
			
		}
		
		

		
	}

	public int getGameStatus() {
		return gameStatus;
	}

	public void setBetAmount(int amount) {
		this.betAmount = amount;
	}

	public int getBetAmount() {
		return betAmount;
	}

	public void setAccountAmount(int amount) {	
		this.accountAmount = amount;
	}

	public int getAccountAmount() {
		return accountAmount;
	}

	/* Feel Free to add any private methods you might need */
	private int[] getCardsTotal(ArrayList<Card> cards) {
		int sum = 0;
		boolean isAceFound = false;
		for (Card card : cards) {
			int cardValue = card.getValue().getIntValue();
			if (cardValue == 1) {
				isAceFound = true;
			}
			sum += cardValue;
		}
		
		// if value is greater than 21, return null
		if (sum > 21) {
			return null;
		}
		
		/*
		 *  return a size of two if two values are possible. For the case of an array of size two, 
		 *  the smaller value must appear in the first array entry.
		 */
		if (!isAceFound) {
			int[] ret = new int[1];
			ret[0] = sum;
			return ret;
		} else {
			//Ace is found. Therefore, we have to take into account Ace being "11"
			
			// we don't want to store values greater than 21
			if (sum + 10 > 21) {
				int[] ret = new int[1];
				ret[0] = sum;
				return ret;
			} else {
				//dealerSum already takes into account Ace being "1"
				int[] ret = new int[2];
				ret[0] = sum;
				ret[1] = sum + 10; 
				return ret;
			}
		}
	}
	
	private int getCardsEvaluation(ArrayList<Card> cards) {
		/*
		 * Returns an integer value that can assume the values LESS_THAN_21 if the player's cards 
		 * have a value less than 21, BUST if the players's cards have a value greater than 21, 
		 * and BLACKJACK if the player has an Ace along with a "10", Jack, Queen, or King. If the 
		 * players' cards have a value equivalent to 21 and the hand does not correspond to a blackjack, 
		 * HAS_21 will be returned.
		 */
		boolean isAceFound = false;
		boolean isTenJackQueenKingFound = false;
		int sum = 0;
		for (Card card : cards) {
			int cardValue = card.getValue().getIntValue();
			sum += cardValue;
			
			if (cardValue == 1) {
				isAceFound = true;
			} else if (cardValue == 10) {
				isTenJackQueenKingFound = true;
			}
		}
		
		if (isAceFound && isTenJackQueenKingFound) {
			return BLACKJACK;
		} else if (sum < 21) {
			return LESS_THAN_21;
		} else if (sum == 21) {
			return HAS_21;
		} else {			
			return BUST;
		}
	}
	
	
	
}