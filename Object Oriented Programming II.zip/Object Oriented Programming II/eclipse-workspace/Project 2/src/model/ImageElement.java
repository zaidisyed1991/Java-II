package model;

public class ImageElement extends TagElement {
	private String imageURL;
	private int width;
	private int height; 
	private String alt;
	private String attributes;
	//  <img src="testudo.jpg" width="84" height="111" alt="Testudo Image">
	public ImageElement(String imageURL, int width, int height, String alt, String attributes) {
		super("img", false, null, concatInstanceAtt(imageURL, width, height, alt, decideContent(attributes)));
		this.imageURL = imageURL;
		this.width = width;
		this.height = height;
		this.alt = alt;
		this.attributes = attributes;
	}
	
	
	private static String decideContent(String attributes) {
		
		if(attributes == null) {
			return "";
		} 
			return attributes;
	}
	
	public String getImageURL() {
		return imageURL;
	}
	private static String concatInstanceAtt(String imageURL, int width, int height, String alt, String attributes) {
		String imgValue = "";
		imgValue = "src=" + "\"" + imageURL + "\" " + "width=" + "\"" + width + "\" " +"height=" + "\"" + height + "\" " + "alt=" + "\"" + alt + "\" " + attributes;
		return imgValue;
	}

}