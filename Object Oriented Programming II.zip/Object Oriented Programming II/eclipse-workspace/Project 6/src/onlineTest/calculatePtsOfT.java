package onlineTest;

import java.io.Serializable;
import java.util.Map;

public class calculatePtsOfT implements Serializable {

	Question crrntQuestion;
	String stdName;
	public calculatePtsOfT (Question question, String stdName) {
		this.crrntQuestion = question;
		this.stdName = stdName;
	}
	
	public calculatePtsOfT (){

	}

	public double calculate() {
		QuestType type = crrntQuestion.getTyp();
	    if( type == (QuestType.TF)) {
	    	boolean tfAnswer = (boolean) crrntQuestion.getStudAnswer(stdName);
	    	if(tfAnswer == (boolean) crrntQuestion.getAnswer()) {
	    		return crrntQuestion.getPoints();
	    	} else {
	    		return 0;
	    	}
	    } else if(type == (QuestType.MC)) {
	    	/*
	    	 * get student answer
	    	 * get there answer
	    	 * compare  
	    	 */
	    	String[] mcSAnswer = (String []) crrntQuestion.getStudAnswer(stdName);
	    	String[] mcQAnswer = (String []) crrntQuestion.getAnswer();
	    	
	       // [ A, B ,C] Array: mcSAnswer
	    	// [ B , C , D]  Array: mcQAnswer
	    	//How to check that all of the values in mcSAnswer == mcQAnswer
	    	// if they are not equal return 0 else return the question point value
	    	if(mcSAnswer.length != mcQAnswer.length) return 0;
	    	int count = 0;
	    	for(int i = 0; i < mcSAnswer.length; i++) {
	    		for (int j = 0; j < mcQAnswer.length; j++) {  
					if(mcSAnswer[i] == mcQAnswer[j]) {
						count++;

					}
				}
	    	}
	    	
	    	if( count == mcQAnswer.length) return crrntQuestion.getPoints();
	    	
	    	return 0;
	    	
	    } else  {
	    	/*
	    	 * loop through all elemnts in arrayB
	    	 *  loop through all in Array B
	    	 *    if we see something that is equal
	    	 *      incr pointvalue  by 1
	    	 *      
	    	 *      return point val
	    	 */
	    
	    	double totalPointsC = 0;
	    	double valueQuest = crrntQuestion.getPoints();
	    	String[] fbSAnswer = (String []) crrntQuestion.getStudAnswer(stdName);
	    	String[] fbQAnswer = (String []) crrntQuestion.getAnswer();
	    	double pointVal = valueQuest / fbQAnswer.length;
	    	for(int i = 0; i < fbSAnswer.length; i++) {
	    		for (int j = 0; j < fbQAnswer.length; j++) {  
					if(fbSAnswer[i] == fbQAnswer[j]) {
						totalPointsC += pointVal;
					}
	    		}
	    	}
	    	
	    	return totalPointsC;
	    }
		 
	
	}
    
	
	
}
