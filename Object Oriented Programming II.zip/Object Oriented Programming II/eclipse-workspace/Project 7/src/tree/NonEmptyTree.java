package tree;

import java.util.Collection;

/**
 * This class represents a non-empty search tree. An instance of this class
 * should contain:
 * <ul>
 * <li>A key
 * <li>A value (that the key maps to)
 * <li>A reference to a left Tree that contains key:value pairs such that the
 * keys in the left Tree are less than the key stored in this tree node.
 * <li>A reference to a right Tree that contains key:value pairs such that the
 * keys in the right Tree are greater than the key stored in this tree node.
 * </ul>
 *  
 */
 public class NonEmptyTree<K extends Comparable<K>, V> implements Tree<K, V> {

	/* Provide whatever instance variables you need */

	/**
	 * Only constructor we need.
	 * @param key
	 * @param value
	 * @param left
	 * @param right
	 */
	 private K key;
	 private V value;
	 Tree<K, V> left;
	 Tree<K, V> right;
	 
	 
	public NonEmptyTree(K key, V value, Tree<K,V> left, Tree<K,V> right) {
		this.key = key;
		this.value = value;
		this.left = left;
		this.right = right;
	}

	public V search(K key) {
		int compare = this.key.compareTo(key);
		if(compare == 0) { 
			return this.value;
		} else if(compare > 0) {
			return this.left.search(key);
		} else {
			return this.right.search(key);
		}
	}
		
	
	public NonEmptyTree<K, V> insert(K key, V value) {
		/*
		 *   3        insert 3
		 *  2  
		 *  
		 *    3    -1
		 *   2  <--- 
		 *  1
		 *     
		 *  
		 *  1
		 *     2  <---
		 *       3 
		 *      
		 *       
		 *       
		 *       
		 */
		int compare = this.key.compareTo(key);
		if( compare == 0) {
			this.value = value;
		} else {
			if(compare > 0) {
				this.left = this.left.insert(key, value);
			} else {
				this.right = this.right.insert(key, value);
			}
		}
		return this;	
	}
	
	public Tree<K, V> delete(K key) {
		/*
		 * 1
		 *   2    dt = 3
		 *    3   =
		 *    
		 *    2   return 2
		 *      3
		 *    
		 *  1   dt = 1
		 *    2
		 *     3
		 *     
		 *    1
		 *      2  dt = 3
		 *      
		 *         3
		 *         
		 *         
		 *         
		 *      2 
		 *   1   3  delete 2
		 *       4
		 *      1
		 *        3
		 *         4
		 *       
		 *       
		 *       1
		 *        3
		 *       2 4
		 *       
		 *       
		 *        7
		 *     4      8       7
		 *    2 5    6  9 
		 *      
		 *    
		 *     
		 *    
		 *    compare the key to given key
		 *         if it exists in the tree
		 *          try
		 *         
			 *          delete element on the left hand side
			 *             replace the maximum key with the current key left
			 *             replace the maximum value with the current value left
			 *    
		 *          catch(EmpTree)
		 *             try
			 *             delete  element on the right hand side
			 *              replace minimum key of the left
			 *              replace minimum value of the left
		 *            catch(EmptTree)
		 *                 EmptyTree NEW eMPTY tREE
		 *            
		 *         ellse if <  current element
		 *             delete on the left hand side
		 *         else
		 *            delete on the rigbt hand side
		 *              
		 *         return this
		 *       
		 *         
		 */
		if(this.key.compareTo(key) == 0) {
			try {
				K maxE = left.max();
				this.key = maxE;
				this.value = left.search(maxE);
				this.left = left.delete(maxE); 
			} catch(TreeIsEmptyException e) {
				try {
					K minE = right.min();
					this.key = minE;
					this.value = right.search(minE);
					this.right = right.delete(minE);
				} catch(TreeIsEmptyException l) {
					return EmptyTree.getInstance();
				}
			}
		} else if(this.key.compareTo(key) > 0) {
			this.left = left.delete(key);
		} else {
			this.right = right.delete(key);
		}
		return this;
	}

	public K max() {
        try {
        	return right.max();
        } catch(TreeIsEmptyException e) {
        	return key;
        }   
	}

	public K min() {
		try {
			return left.min();
		} catch(TreeIsEmptyException e) {
			return key;
		}
	}
/*
 *  1  1+  2 + 1
 * 2  3  1+ 1 + 0
 * *    4  1+ 0 + 0  
 * 					from torang       fromk  tk8
 *   3      range =  6 - 8  3 < 6      6   7    8  
 *     5         key < f from recurse right
 *      6
 *       7 
 *         8
 *         
 *     4    range =  1 - 3     <= end      >=  from   4 > 3
 *   2   5         < end  recurse left 
 *  1     6
 *  
 *    4
 *  2   5    range = 4- 4
 * 1     6
 *
 * 
 */   
	public int size() {
		return 1 + right.size() + left.size();
	}

	public void addKeysToCollection(Collection<K> c) {

		/*   
		 * 	  2
		 * 1    3
		 *       4
		 *       
		 *     c: [1 2 3]
		 *     
		 *     
		 
		 *    
		 *    
		 */
		left.addKeysToCollection(c);
		c.add(key);
		right.addKeysToCollection(c);	
	}
	
	public Tree<K,V> subTree(K fromKey, K toKey) {
		if(key.compareTo(fromKey) < 0) {   
			return right.subTree(fromKey, toKey);
		} else if(key.compareTo(toKey) > 0) {
			return left.subTree(fromKey, toKey);
		} else {
			NonEmptyTree<K,V> newTree = new NonEmptyTree(key,value, left.subTree(fromKey, toKey), right.subTree(fromKey, toKey));
			return newTree;
		}	
	}
	
	public int height() {
		return 1 + Math.max(left.height(), right.height());
	}
	
	public void inorderTraversal(TraversalTask<K,V> p) {
		/* 2
		 *1 3
		 *   4        f(2)
		 *            f(1)
		 *            f(empty)
		 *            
		 *              
		 *                  f(2) ptr 2
		 *             f(1) ptr 1  f(3) ptr 3
		 *                       f(*) 
		 *           f(*) f(*)          f(4) ptr 4
		 *          	            f(*)  f(*)
		 *            
		 *            
		 *            
		 *  
		 *  left root right
		 *  1234
		 *  
		 *  root l right
		 *  2 1
		 *  
		 *  left right root
		 *     2				f(2)
		 *   1  3
		 *       4             ^
		 *         			1  / f(1)
		 *   1 4  3 2       ^ 		   ^
		 *               0 / f(*)  f*)  \ 0
		 *                
		 */
		left.inorderTraversal(p);
		p.performTask(key, value);
		right.inorderTraversal(p);	
	}
	
	public void rightRootLeftTraversal(TraversalTask<K,V> p) {
		right.rightRootLeftTraversal(p);
		p.performTask(key, value);
		left.rightRootLeftTraversal(p);
	}	
}