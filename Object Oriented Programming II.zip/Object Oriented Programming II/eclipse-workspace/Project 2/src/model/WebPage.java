package model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




public class WebPage implements Comparable<WebPage> {
    private ArrayList<Element> elements = new ArrayList<Element>();
    String title = "";
    private static boolean isEnabled;

    public WebPage(String title) {
        this.title = title;
    }

    @Override
    public int compareTo(WebPage o) {
        // TODO Auto-generated method stub
        for (int i = 0; i < title.length() &&
                i < o.title.length(); i++) {
            if ((int)title.charAt(i) ==
                    (int)o.title.charAt(i)) {
                continue;
            }
            else {
                return (int)title.charAt(i) -
                        (int)o.title.charAt(i);
            }
        }

        // Edge case
        if (title.length() < o.title.length()) {
            return (title.length()-o.title.length());
        }
        else if (title.length() > o.title.length()) {
            return (title.length() - o.title.length());
        }
        // it implies both the strings are equal 
        else {
            return 0;
        }
    }

    public int addElement(Element element) {
        elements.add(element);
        if(element instanceof TagElement ) {
            return ((TagElement) element).getId();
        }
        return -1;
    }
    public static void enableId(boolean choice) {
        WebPage.isEnabled = choice;
    }

    public Element findElem(int id) {
        for (int i = 0; i < elements.size(); i++) {
            if(((TagElement) elements.get(i)).getId() == id) {;
                return elements.get(i);
            }
        }
        return null;
    }

    public String getWebPageHTML(int indentation) {

		/*  [ 1  2    3      ]
		 *
		 * <!doctype html>
<html>
   <head>
      <meta charset="utf-8"/>
      <title>Example1</title>
   </head>
   <body>
   </body>
</html>
		 *
		 *
		 *
		 * Traverse array
		 *   addIndentation
		 * 	add Tagname
		 * 	add  new line
		 * 	add text if it has next
		 * 	add closing tag
		 *
		 *
		 *
		 *
		 *
		 */
        String html = "";
        html += "<!doctype html>\n";
        html += "<html>\n";
        html += indent(indentation);
        html += "<head>\n";
        html += indent(indentation * 2);
        html += "<meta charset=\"utf-8\"/>\n";
        html += indent(indentation * 2);
        html += "<title>";
        html += title;
        html += "</title>\n";
        html += indent(indentation);
        html += "</head>\n";
        html += indent(indentation);
        html += "<body>\n";
        for (Element e : elements) {
            html += e.genHTML(indentation);
            html += "\n";
        }
        html += indent(indentation);
        html += "</body>\n";
        html += "</html>\n";
        return html;
    }

    public void writeToFile(String filename, int indentation) {
        String result = "";
        result += getWebPageHTML(indentation);


      try {

          File yourFile = new File(filename);
          yourFile.createNewFile();
      } catch (IOException e){
          System.out.println("something went wrong creating file");
      }
        Utilities.writeToFile(filename, result);
    }
    /*
     *  List Count: 1
    Paragraph Count: 0
    Table Count: 2
    TableElement Utilization: 75.0

    /* [  li    h   p     ]
     *   if we have an instance of a list element
            countList++
          else if instance of p elemnt
            counrparagraph++
          else instance of tableElement
              counttable ++

         create String with anmes of elements emicolon and count newline

     */
	/*
	 *   <table>
      <tr><td>Dog</td><td></td></tr>
      <tr><td></td><td>Cat</td></tr>  4  1/4   4    2
   </table>
   <table>
      <tr><td>Red</td><td>Blue</td></tr>
      <tr><td>Green</td><td>Yellow</td></tr>
   </table>

	 * store the result of the genHtML FOR TABLEeLEMENT
	 * regex matcth that  looks for  <td>
	 *  count++
	 * getutilization of table
	 * totalsizecrrntalbe = count
	 * TotalSize += totalsizeccrrnttable
	 *  loop through array
	 *     get utilization of each
	 *     get size of each
	 *    crrnutlofeach = crrntsizetable -  utilization * crrntsizeTable
	 *
	 * nonutilizedRows+= crrnnutofeach
	 *
	 */
    // totalsize - nonutilizedRows) / totalsize
    private static int findTd(String tableString) {
        String in = tableString;
        int count = 0;
        Pattern p = Pattern.compile("<td>");
        Matcher m = p.matcher( in );
        while (m.find()) {
            count++;
        }
        return count;
    }
    private static Double getcrrntTableUtil(ArrayList<Integer> sizeTble,ArrayList<Double> utilStore){
        Double crrntUtil = 0.0;
        for( int i = 0; i < sizeTble.size(); i++){
            crrntUtil += sizeTble.get(i) - ((utilStore.get(i)/100) * sizeTble.get(i));
        }
        return crrntUtil;
    }
    public String stats(){
        ArrayList<Double> utilStore = new ArrayList<Double>();
        ArrayList<Integer> sizeTble = new ArrayList<Integer>();
        int countList = 0;
        int countParagraph = 0;
        int countTable = 0;
        double tableUtil = 0.0;
        String statsWeb = "";
        String tableString = "";
        int totalSizeCrrntTable = 0;
        int totalSize = 0;
        double nonUnitlizedRows = 0;
        double totalWebUtil = 0;
        double crrntTbUtil = 0;
        Element e = null;
        for (int i = 0; i < elements.size(); i++) {
            e = elements.get(i);
            if (e instanceof ListElement) {
                countList++;
            } else if (e instanceof ParagraphElement) {
                countParagraph++;
            } else {
                utilStore.add(((TableElement) e).getTableUtilization());
                //tableUtil += ((TableElement) e).getTableUtilization();
                tableString += ((TableElement) e).genHTML(0);
                //System.out.println(tableString);
                sizeTble.add(findTd(tableString));
                totalSizeCrrntTable = findTd(tableString);
                //System.out.println(totalSizeCrrntTable);
                totalSize = totalSizeCrrntTable;
                countTable++;
            }
        }

        crrntTbUtil += getcrrntTableUtil(sizeTble, utilStore);
        totalWebUtil = ((totalSize - crrntTbUtil)/totalSize) * 100;
        statsWeb += "List Count: " + countList + "\n";
        statsWeb += "Paragraph Count: " + countParagraph + "\n";
        statsWeb += "Table Count: " + countTable + "\n";
        statsWeb += "TableElement Utilization: " + totalWebUtil + "\n";

        /*
         *
         * otal cells used in webpage divided by
         *
         * total cells in webpage.
         *  Don't just average the percents of each table.
         *
         *
         *
         */
        return statsWeb;
    }

    private String indent(int indentation) {
        String result = "";
        for (int j = 0; j < indentation; j++) {
            result+= " ";
        }
        return result;
    }
    
    
}
