package processor;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Client {
	Map<String,Integer> quantItems;
	String id;
	public Client(String id) {
		quantItems = new TreeMap<>();
		this.id = id;
	}

	public void setQuantItems(Item item) {
		int count = quantItems.getOrDefault(item.name, 0);
		quantItems.put(item.name, count + 1);
	}

	public Map<String, Integer> getQuantItems() {
		return quantItems;
	}

	


	
	
}
