package model;

public class TextElement implements Element {
	String text;
	
	public TextElement(String text){
		this.text = text;
	}
	public String genHTML(int indentation){
		String result = "";
		for (int i = 0; i < indentation; i++) {
			result+= " ";
		}
		result += text;
		return result;
	}

	
	
}
