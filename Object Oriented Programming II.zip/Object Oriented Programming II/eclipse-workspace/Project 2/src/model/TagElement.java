//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package model;

public class TagElement implements Element {
    private String tagName;
    private boolean endTag;
    private Element content;
    private String attributes;
    private static int count = 0;
    private int id = 0;
    private static boolean isEnabled;

    public TagElement(String tagName, boolean endTag, Element content, String attributes) {
        this.tagName = tagName;
        this.endTag = endTag;
        this.content = content;
        this.attributes = attributes;
        this.id = ++count;
    }

    public String genHTML(int indentation) {
        String result = "";

        for(int i = 0; i < indentation; ++i) {
            result = result + " ";
        }

        result = result + this.decideToAddTag();
        return result;
    }

    public int getId() {
        return this.id;
    }

    public String getStringId() {
        return this.tagName + this.id;
    }

    public static void enableId(boolean choice) {
        isEnabled = choice;
    }

    public String getStartTag() {
        String result = "";
        if (isEnabled) {
            result = this.addIdStartTagAttribute();
            return result;
        } else {
            return this.addStartTagAttribute();
        }
    }

    public String getEndTag() {
        return "</" + this.tagName + ">";
    }

    public void setAttributes(String attributes) {
        this.attributes = attributes;
    }

    public static void resetIds() {
        count = 0;
    }

    private String addIdStartTagAttributeWithSpace() {
        return "<" + this.tagName + " " + "id=" + "\"" + this.tagName + this.id + "\"" + " " + this.attributes + ">";
    }

    private String addIdStartTagAttribute() {
        System.out.println("tagname:" + this.tagName + "attributes:" + this.attributes);
        return "<" + this.tagName + " id=" + "\"" + this.tagName + this.id + "\"" + this.attributes + ">";
    }

    private String addStartTagAttributeWithSpace() {
        return "<" + this.tagName + " " + this.attributes + ">";
    }

    private String addStartTagAttribute() {
        return "<" + this.tagName + this.attributes + ">";
    }

    private String closingTagAttribute() {
        return "</" + this.tagName + ">";
    }

    private String decideToAddTag() {
        String result = "";
        /*
           run if id and no id
           issue  is if theres an id a space gets addedright after
             if there is (empty attributes then no space should be added

         */
        if (isEnabled) {
            if (this.endTag) {
                if (this.attributes == "") {
                    result = result + this.addIdStartTagAttribute() + this.content.genHTML(0) + this.closingTagAttribute();
                } else{
                    result = result + this.addIdStartTagAttributeWithSpace() + this.content.genHTML(0) + this.closingTagAttribute();

                }
            } else {
                if (this.attributes == "") {
                    result = result + this.addIdStartTagAttribute();
                } else{
                    result = result + this.addIdStartTagAttributeWithSpace();
                }
            }

            return result;
        } else {
            if (this.endTag) {
                if (this.attributes == "") {
                    result = result + this.addStartTagAttribute() + this.content.genHTML(0) + this.closingTagAttribute();
                } else {
                    result = result + this.addStartTagAttributeWithSpace() + this.content.genHTML(0) + this.closingTagAttribute();
                }
            } else if (this.attributes == "") {
                result = result + this.addStartTagAttribute();
            } else {
                result = result + this.addStartTagAttributeWithSpace();
            }

            return result;
        }
    }
}
