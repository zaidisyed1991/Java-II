package processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.*;

import tests.TestingSupport;

import java.io.FileNotFoundException;

public class OrderManager {
	private TestingSupport supportPrint;
	private String fileName;
	private String threadCount;
	private int numOrders;
	private String basefileName;
	private String resultFileName;
	private List<Item> items;
	private List<Client> clientList;
	private Map<String, Integer> numSold;
	public OrderManager(String fileName,
						String threadCount, int numOrders, String basefileName,
						String resultFileName) {
		this.basefileName = basefileName;
		this.threadCount = threadCount;
		this.resultFileName = resultFileName;
		this.numOrders = numOrders;
		this.fileName = fileName;
		items = new ArrayList<>();
		clientList = new ArrayList<>();
		numSold = new HashMap<>();
		supportPrint = new TestingSupport();
	}

	public boolean processOrderItemData() {


		File file = new File(fileName);
		try {
			// Create a new Scanner object which will read the data
			// from the file passed in. To check if there are more
			// line to read from it we check by calling the
			// scanner.hasNextLine() method. We then read line one
			// by one till all lines is read.
			Scanner scanner = new Scanner(file);
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String[] namePrice = line.split(" ");
				Item item = new Item(namePrice[0], namePrice[1]);
				items.add(item);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return false;
		}
/*
		for (Item item : items) {
			System.out.println("name" + item.name + " price" + item.price);
		}
*/
		return true;
	}

	public void readFiles(int i, File file) {
		try {
			// Create a new Scanner object which will read the data
			// from the file passed in. To check if there are more
			// line to read from it we check by calling the
			// scanner.hasNextLine() method. We then read line one
			// by one till all lines is read.
			TestingSupport supp = new TestingSupport();
			String answer = "";
			Scanner scanner = new Scanner(file);
			String clientInfo = scanner.nextLine();
			String[] id = clientInfo.split(" ");
            Client client = new Client(id[1]);
			clientList.add(client);
            System.out.println("Reading order for client with id:" + id[1]);
			while (scanner.hasNextLine()) {
				//numOrders
				//if basename is "example" and the number of orders is 3, the files will be named example1.txt,
				// example2.txt, and example3.txt. Find a way to generate those
				// strings from the basename and number of orders, then use a java
				// class to read from the file with that name (such as Scanner).
				String line = scanner.nextLine();
				String[] namePrice = line.split(" ");
				Item item = new Item(namePrice[0], namePrice[1]);
				
                client.setQuantItems(item);

				//answer += "Item's name: " + name
				//System.out.println("namePrice" + namePrice[0] + "namePrice" + namePrice[1]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();

		}
	}
	
	public void writeToFile() {
        DecimalFormat df = new DecimalFormat("#,###,##0.00");
		String answer = "";
		double total = 0;
		double grandT = 0;
		String grandTotalS = " ";
		for(Client client: clientList) {
			String id = client.id;
			answer += "----- Order details for client with Id: "+ id + " -----\n";
			total = 0;
			for(Map.Entry<String,Integer>entry: client.getQuantItems().entrySet()) {
				answer += "Item's name: ";
				String itemName = entry.getKey();
				int quant = entry.getValue();
				for(Item item: items) {
					double price = Double.parseDouble(item.price);
					String priceString = df.format(price);
					String priceQuant = df.format(quant * price);
					if(itemName.equals(item.name)) {
						int count = numSold.getOrDefault(itemName, 0);
						numSold.put(itemName, count + quant);
						total += quant * price;
						answer += itemName + ", Cost per item: $" + priceString +", ";
						answer += "Quantity: " + quant + "," + " ";
						answer += "Cost: $" + priceQuant + "\n";
								
					}
				}
			}		
			grandT += total;
			String totalString = df.format(total);
			answer += "Order Total: $" +  totalString + "\n";
		}
		
		grandTotalS = df.format(grandT);
		Collections.sort(items, new Comparator<Item>() {
		    public int compare(Item v1, Item v2) {
		        return v1.name.compareTo(v2.name);
		    }
		});
		answer += "***** Summary of all orders *****\r\n";
		//Blu-Ray vs BluRay?
		for(Item item: items) {
			int nSold = numSold.get(item.name);
			String priceQuant = df.format(nSold * Double.parseDouble(item.price));
			answer += "Summary - Item's name: " + item.name + ", ";
			answer += "Cost per item: $" + item.price + ", ";
			answer +=  "Number sold: " + nSold + ", " + "Item's Total: $" + priceQuant + "\n";
					
		}
		answer += "Summary Grand Total: $" + grandTotalS + "\n";
 
		supportPrint.appendStringToFile(resultFileName, answer);
	}
   

	public void processOrderBaseData() {
		// have a general function that a thread can call;
		if (threadCount.equals("y")) {
			//Thread[] allThreads = new Thread[numOrders];
			List<Thread> allThreads = new ArrayList<>();
			Object lock = new Object();
			for (int i = 1; i <= numOrders; i++) {
				File file = new File(basefileName + i + ".txt");
				allThreads.add( new Thread(new OrderCalculator(lock, i, file, clientList)));

			}
			for (Thread thread : allThreads)
				thread.start();
			try {
				for (Thread thread : allThreads)
					thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		} else {
			for (int i = 1; i <= numOrders; i++) {
				File file = new File(basefileName + i + ".txt");
				readFiles(i, file);
			}
			
			//move to  if else
		}
		
		Collections.sort(clientList, new Comparator<Client>() {
		    @Override
		    public int compare(Client o1,Client o2) {
		    	Integer first = Integer.parseInt(o1.id);
		    	Integer second = Integer.parseInt(o2.id);
    			return first.compareTo(second);
		    }
		});
		
		writeToFile();		

	}
}
/*
nter item's data file name:  itemsData.txt
Enter 'y' for multiple threads, any other character otherwise: y
Enter number of orders to process: 3
Enter order's base filename: example
Enter result's filename: resultsExample.txt
Reading order for client with id: 1003
Reading order for client with id: 1001
Reading order for client with id: 1002
Processing time (msec): 51
Results can be found in the file: resultsExample.txt
 */