package listClasses;

import org.junit.Assert;

import java.util.*;


public class BasicLinkedList<T> implements Iterable<T>{


	protected class Node<T> {
		protected T data;
		protected Node next;     // [1|*]     [ 2  |*  ]

		protected Node(T data) {
			this.data = data;
		}
	}

	protected Node head;
	protected Node tail;
	protected int size;

	public BasicLinkedList() {
		// Defines an empty linked list.
		//No nodes are created. We do not use dummy nodes for this list
		//(if you don't know what a dummy list is don't worry about it).

	}

	public String toString() {
		String result = "\" ";
		Node curr = head;

		while (curr != null) {
			result += curr.data + " ";

			curr = curr.next;
		}

		return result + "\"";
	}

	public T getFirst(){
		if(head == null) return null;
		return (T) head.data;
	}

	public T getLast(){
		if(head == null) return null;
		return (T) tail.data;
	}

	public T retrieveFirstElement() {
		//  1  - >  2 -- > 3       null         1
		/*
		 *  remove
		 *  store the element
		 *  return the elemtn
		 *
		 *  if( head == null) return null;
		 *  if( head.next == null) return head;;
		 *  Node firstElement = head;
		 *  Node fast = head.next;
		 *  head = fast;
		 *  return firstElement;
		 *
		 *
		 */


		if( head == null) return null;
		if( head.next == null) {
			T result = (T) head.data;
			head = null;
			return result;
		}
		Node firstElement = head;
		Node fast = head.next;
		head = fast;
		size--;
		return (T) firstElement.data;



	}
	//  [  1 , 2 ,3 , 4 ]  find the elemnt before 3  traverse array 3s index -1 is found retun it return value
	public T retrieveLastElement() {
		// 1 - >  2  - > 3 <- tail    null       1       returns 3
		// 1 - > (tail) 2 -> null-> null
		/* return tail
		  remove remove tail
		  stores tail for removal later */
		  System.out.println(this.toString());
		if(tail == null) return null;
		if(head.next == null) return (T) head.data;
		Node lastElement = tail;
		Node ptr = head;
		//find the 2nd to last element or the elemnt before the tail
		//need to start at he head
		//iterate with ptr.next
		while( ptr.next !=null) {
			// this condition lets us know where the second to last element is
			System.out.println(ptr.data);
			if( ptr.next == tail){
				Node elementBeforeTail = ptr;
				// once we found second to last eleent we set the tail to the ptr
				tail = elementBeforeTail;

			}
			// iterates through list until we reach the condiiton
			ptr = ptr.next;
		}

		tail.next = null;
		size--;
           System.out.println(this.toString());
		return (T) lastElement.data;

	}

	public BasicLinkedList<T> addToFront(T data){

		//  head           5
		Node n = new Node(data);
		if(head == null) {
			head = n;
			tail = n;
		} else {

			n.next = head;
			head = n;
		}
		size++;
		return this;
	}
	public BasicLinkedList<T> addToEnd(T data){
		Node newNode = new Node(data);
		if(head == null) {
			head = newNode;
			tail = newNode;
		}
		tail.next = newNode;
		tail = newNode;
		size++;
		//4-3-2 <- tail
		return this;
	}
	
	public int getSize(){
		return size;
	}

	public BasicLinkedList<T> remove(T targetData, Comparator<T> comparator){
		Node ptr = head;
		Node slow = head;
		BasicLinkedList <T> emptyResult = new BasicLinkedList<>();
		if(head == null) return emptyResult;
        
		while(ptr != null){
			int  comp = comparator.compare((T) ptr.data, targetData);
			if(comp == 0){
				slow.next =  ptr.next;
				if(ptr == tail){
					tail = slow;
				}
				if(ptr == head){
					head = slow;
					head = slow.next;
				}
				size--;
			}
			slow = ptr;
			ptr = ptr.next;

		}
		return this;
	}

	public ArrayList<T> getReverseArrayList(){

		ArrayList<T>  result = new ArrayList<>();
		BasicLinkedList revList = getReverseList();
		Node ptr = revList.head;
		while(ptr !=null) {
			result.add((T) ptr.data); 
			ptr = ptr.next;
		}
		
		return result;
	}

	public void getReverseList(Node fast, Node slow){
		if(fast !=null) head = fast;	
		if(fast == null) return;
		Node temp = fast.next;
		fast.next = slow;
		slow = fast;
		fast = temp;
		getReverseList(fast, slow);
		
		//3 - 1 - 2 -4
          //tail head
	}

	public BasicLinkedList<T> getReverseList(){
		BasicLinkedList<T> result = new BasicLinkedList<>();
		if( head == null) return result;
		Node tempTail = tail;
		getReverseList(head,null);
		Node temp = head;
		tail = tempTail;
		return this;
	}


	@Override
	public Iterator<T> iterator() {
		return new Iterator<T>() {
			Node current = null;
			boolean isNextE =  true;
			// are we at the start? check and if we arent return if theres something next
			@Override
			public boolean hasNext() {

				//if we are at the start and there is something in the list
				if(current == null && head != null){
					return true;
				} else if(current != null){
					return current.next != null;
				}

				return false;
			}

			@Override
			public T next() {
				// go through the list if it has next and return it
				if( current == null && head != null){
					current = head;
					return (T) head.data;
				} else if( current != null){
					current = current.next;
					T value = (T) current.data;
					return value;
				}

				throw new NoSuchElementException();
			}
		};
		// TODO Auto-generated method stub
	}
	
	public static void main(String[] args) {
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(1);
		basic.addToEnd(2);
		String crr = "";
		//String crr = basic.toString();
		//Assert.assertEquals("\" 1 2 \"", crr);	
		basic.retrieveLastElement();
		crr = basic.toString();
		Assert.assertEquals("\" 1 \"", crr);
	}

}