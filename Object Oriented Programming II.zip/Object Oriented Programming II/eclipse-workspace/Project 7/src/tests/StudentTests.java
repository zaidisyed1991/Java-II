package tests;


import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.Test;

import tree.EmptyTree;
import tree.NonEmptyTree;
import tree.PlaceKeysValuesInArrayLists;
import tree.PolymorphicBST;

import junit.framework.TestCase;
import tree.PolymorphicBST;

public class StudentTests extends TestCase {
	@Test
	public void testMaxNonEmpty() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();
		ptree.put(2, "Two");
		String answer = ptree.toString();
		Object k = ptree.getMax();
		assertEquals(new Integer(2), k);
	}
	
	public void testSizeHeight() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();
		ptree.put(2, "Two");
		ptree.put(1, "One");
		ptree.put(3, "Three");
		ptree.put(4, "Four");
		assertEquals(4, ptree.size());
		assertEquals(3, ptree.height());

	}
	
	
	@Test
	public void testDelete() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();	
		assertEquals(0, ptree.size());
		ptree.put(2, "Two");
		ptree.put(1, "One");
		ptree.put(3, "Three");
		ptree.put(1, "OneSecondTime");
		/*
		 *  2
		 * 1  3
		 * 
		 */
		
		ptree.remove(1);
		ptree.remove(2);
		assertEquals(1, ptree.size());
	}
	
	@Test
	public void testKeySet() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();	
		assertEquals(0, ptree.size());
		ptree.put(2, "Two");
		ptree.put(1, "One");
		ptree.put(3, "Three");
		ptree.put(1, "OneSecondTime");
		String answer =  ptree.keySet().toString();
		assertEquals("[1, 2, 3]", answer);	
	}
	
	@Test
	public void testRightRootLeftTraversal() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();
		assertEquals(0, ptree.size());
		ptree.put(4, "four");
		ptree.put(1, "one");
		ptree.put(0, "zero");
		ptree.put(2, "two");
		ptree.put(3, "three");
		ptree.put(5, "five");
		ptree.put(8, "eight");
		ptree.put(7, "seven");
		ptree.put(6, "six");
		ptree.put(9, "nine");
		
		PlaceKeysValuesInArrayLists<Integer, String> task = new PlaceKeysValuesInArrayLists<Integer, String>();
		ptree.rightRootLeftTraversal(task);
		assertEquals(task.getKeys().toString(), "[9, 8, 7, 6, 5, 4, 3, 2, 1, 0]");
		assertEquals(task.getValues().toString(),"[nine, eight, seven, six, five, four, three, two, one, zero]");	
	}
	
	@Test
	public void testInOrderTraversal() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();
		assertEquals(0, ptree.size());
		ptree.put(4, "four");
		ptree.put(1, "one");
		ptree.put(0, "zero");
		ptree.put(2, "two");
		ptree.put(3, "three");
		ptree.put(5, "five");
		ptree.put(8, "eight");
		ptree.put(7, "seven");
		ptree.put(6, "six");
		ptree.put(9, "nine");
		
		PlaceKeysValuesInArrayLists<Integer, String> task = new PlaceKeysValuesInArrayLists<Integer, String>();
		ptree.inorderTraversal(task);
		assertEquals(task.getKeys().toString(),"[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]");
		assertEquals(task.getValues().toString(),"[zero, one, two, three, four, five, six, seven, eight, nine]");
	}
	
	@Test
	public void testSubMap() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();
		assertEquals(0, ptree.size());
		ptree.put(4, "four");
		ptree.put(1, "one");
		ptree.put(0, "zero");
		ptree.put(2, "two");
		ptree.put(3, "three");
		ptree.put(5, "five");
		ptree.put(8, "eight");
		ptree.put(7, "seven");
		ptree.put(6, "six");
		ptree.put(9, "nine");
		assertEquals(5,ptree.height());
		assertEquals(10, ptree.size());

		PolymorphicBST<Integer,String> nxt = ptree.subMap(4, 9);
		assertEquals(nxt.keySet().toString(), "[4, 5, 6, 7, 8, 9]" );
	}
	
	@Test
	public void testPerm() {
		PolymorphicBST<Integer,String> ptree = new PolymorphicBST<Integer,String>();
		ptree.remove(0);
		ptree.put(1, "one");
		assertEquals(1, ptree.size());
		ptree.clear();
		PolymorphicBST<Integer,String> nxt = ptree.subMap(4, 9);
		assertEquals(nxt.keySet().toString(), "[]" );
		assertEquals(0,ptree.height());
		ptree.put(4, "four");
		ptree.put(1, "one");
		ptree.put(0, "zero");
		ptree.put(2, "two");
		ptree.put(3, "three");
		ptree.put(5, "five");
		ptree.put(8, "eight");
		ptree.put(7, "seven");
		ptree.put(6, "six");
		ptree.put(9, "nine");
		ptree.remove(5);
		ptree.remove(8);
		assertEquals(ptree.keySet().toString(),"[0, 1, 2, 3, 4, 6, 7, 9]");

		assertEquals("nine",ptree.get(9));
	}
	
	/*
	 *    *
	 *    
	 *    1
	 *      2
	 *        3
	 *        
	 *        
	 *    1
	 *    
	 *  2   3
	 *        4
	 *        
	 *        
	 *      1  
	 *     
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	
}