//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package model;

import java.util.ArrayList;

public class ListElement extends TagElement {
    private static boolean ordered;
    private String attributes;
    private ArrayList<Element> listElement;

    public ListElement(boolean ordered, String attributes) {
        super(decideOrder(ordered), false, (Element)null, decideContent(attributes));
        ListElement.ordered = ordered;
        this.attributes = attributes;
        this.listElement = new ArrayList();
    }

    public void addItem(Element item) {
        this.listElement.add(item);
    }

    private String addIndent(int indentation, String result) {
        for(int j = 0; j < indentation; ++j) {
            result = result + " ";
        }

        return result;
    }

    public String genHTML(int indentation) {
        String result = "";
        result = result + super.genHTML(indentation);
        result = result + "\n";

        int i;
        for(i = 0; i < this.listElement.size(); ++i) {
            result = this.addIndent(indentation + 3, result);
            result = result + "<li>";
            result = result + "\n";
            result = this.addIndent(indentation + 3, result);
            Element e = (Element)this.listElement.get(i);
            result = result + e.genHTML(3);
            result = result + "\n";
            result = this.addIndent(indentation + 3, result);
            result = result + "</li>";
            result = result + "\n";
        }

        for(i = 0; i < indentation; ++i) {
            result = result + " ";
        }

        result = result + this.getEndTag();
        return result;
    }

    private static String decideOrder(boolean ordered) {
        return ordered ? "ol" : "ul";
    }

    private static String decideContent(String attributes) {
        return attributes == null ? "" : attributes;
    }


}