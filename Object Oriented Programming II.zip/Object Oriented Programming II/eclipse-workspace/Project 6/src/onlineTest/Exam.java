package onlineTest;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

class Exam implements Serializable{
	private Map<String , Double> accStudPts = new HashMap<>();
	private int id;
	private String title;
	private Map<Integer, Question> questions;
	private double totalPoints;

	public Exam( String title, int id) {
		this.title = title;
		this.id = id;
		questions = new HashMap<>();
	}

	public Exam(int id) {
		this.id = id;
		questions = new HashMap<>();

	}
	/*
	 * Exam ( everyone shares exam)
	 *    questions
	 *    
	 * Questions
	 *    answer
	 *    points
	 *    
	 *              
	 *  j [Exam:points]     c      b
	 *  1(0)                1(1)    1
	 *  setp              setp      setp
	 *  
	 * 
	 */
    
	public double getTotalPoints() {
		for(Map.Entry<Integer, Question> entry: questions.entrySet()) {
			Question question = entry.getValue();
			this.totalPoints += question.getPoints();
		}
		return totalPoints;
	}
	
	public double getAccStudPts(String studName) {
		return accStudPts.get(studName);
	}

	public void setAccStudPts(double accPts, String studName) {
		this.accStudPts.put(studName, accStudPts.getOrDefault(studName, (double) 0 )+ accPts);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Map<Integer, Question> getQuestions() {
		return questions;
	}

	public Question getOneQuetion(int number) {
		return questions.get(number);
	}

	public void setQuestions(Question question) {
		int questNumber = question.getQuestionNumber();
		this.questions.put(questNumber, question);
	}

	@Override
	public String toString() {
		String result = "";
		result += "Exam " + this.id;
		for(Map.Entry<Integer, Question>entry: questions.entrySet()) {
			Question crrntQuestion = entry.getValue();
			result += crrntQuestion.getQuestionNumber() +" " + crrntQuestion.getText() +
					" " + crrntQuestion.getPoints() + " ";

			if(crrntQuestion.getAnswer() instanceof String[]) {
				String[] allAnswers = (String[]) crrntQuestion.getAnswer();
				for(String s: allAnswers) {
					result += s;
				}
			} else {
				result += String.valueOf(crrntQuestion.getAnswer());
			}
			result += "\n";
		}
		return result;
	}

	/*
	 * 
	 * 
	 * 
	 * 
	 */

}
