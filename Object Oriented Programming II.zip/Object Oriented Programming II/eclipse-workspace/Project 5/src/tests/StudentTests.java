package tests;

import listClasses.SortedLinkedList;
import org.junit.Assert;
import org.junit.Test;

import listClasses.BasicLinkedList;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.SortedMap;

public class StudentTests {

	@Test
	public void StudentTest1retrieveLastElement() {
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(4);
		basic.addToFront(5);
		basic.addToFront(5);
		basic.retrieveFirstElement();
		String crr = basic.toString();
		Assert.assertEquals("\" 5 4 \"", crr);
	}

	@Test
	public void StudentTestaddToFront() {

	}

	@Test
	public void StudentTestReverseAList() {
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(4);
		basic.addToFront(5);
		basic.addToFront(6);
		basic.addToFront(4);
		ArrayList<?> answer = basic.getReverseArrayList();
		String crr = answer.toString();

		//Assert.assertEquals("[4, 5, 6, 4]", crr);
		
		// 4 6  5 4 
		//  4  5 6 4
	}

	@Test
	public void StudentTestReverseAListTwo() {
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(4);
	    basic.addToFront(5);
		basic.addToFront(6);
		basic.addToFront(4);  // 74654
		basic.addToFront(7);
		ArrayList<?> answer = basic.getReverseArrayList();
		String crr = answer.toString();

		Assert.assertEquals("[4, 5, 6, 4, 7]", crr);
	}

	@Test
	public void StudentTestReverseList(){
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(4);
	    basic.addToFront(5);
		basic.addToFront(6);
		basic.addToFront(4);
		basic.addToFront(7);
		basic = basic.getReverseList();
		String crr = basic.toString();
		Assert.assertEquals("\" 4 5 6 4 7 \"", crr);
	}
	
	@Test
	public void StudentTestReverseListSecond(){
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(4);
		basic.addToEnd(3);
		basic.addToEnd(1);
		
		basic = basic.getReverseList();
		String crr = basic.toString();
		Assert.assertEquals("\" 1 3 4 \"", crr);
	}
	@Test
	public void StudentTestIterator(){
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(4);
		basic.addToFront(5);
		basic.addToFront(6);
		basic.addToFront(4);
		Iterator it = basic.iterator();
		String crr = "";
		int count = 0;
		while(it.hasNext()){
			crr+= it.next() + ",";
		}

		Assert.assertEquals("4,6,5,4,", crr);
	}

	
	@Test
	public void StudentSortedAdd(){
		SortedLinkedList basic = new SortedLinkedList(Comparator.naturalOrder());
		basic.addToFront(4);
		basic.addToFront(5);
		basic.addToFront(6);
		basic.addToFront(4);
		basic.add(4);
		String crr = basic.toString();
		String test = "\" 4 4 6 5 4 \"";
		Assert.assertEquals(test, crr);

	}

	@Test
	public void StudentSortedAddtwo(){
		SortedLinkedList basic = new SortedLinkedList(Comparator.naturalOrder());
		basic.addToFront(3);
		basic.addToFront(2);
		basic.addToFront(1);
		basic.add(2);
		String crr = basic.toString();
		String test = "\" 1 2 2 3 \"";
		Assert.assertEquals(test, crr);
	}
  

	@Test
	public void StudentSortedAddthree(){
		SortedLinkedList basic = new SortedLinkedList(Comparator.naturalOrder());
		basic.add(7);
		basic.add(7);
		basic.add(7);
		basic.add(7);
		basic.add(7);
		String crr = basic.toString();
		String test = "\" 7 7 7 7 7 \"";
		Assert.assertEquals(test, crr);
	}

	
	@Test
	public void StudentSortedAddfour(){
		SortedLinkedList basic = new SortedLinkedList(Comparator.naturalOrder());
		basic.addToFront(3);
		basic.addToFront(2);
		basic.addToFront(1);
		basic.add(4);
		String crr = basic.toString();
		String test = "\" 1 2 3 4 \"";
		Assert.assertEquals(test, crr);
	}
  

	@Test
	public void StudentSortedremove(){
		SortedLinkedList basic = new SortedLinkedList(Comparator.naturalOrder());
		basic.addToFront(3);
		basic.addToFront(2);
		basic.addToFront(1);
		basic.remove(1);
		String crr = basic.toString();
		String test = "\" 2 3 \"";
		Assert.assertEquals(test, crr);
	}
	


	@Test
	public void StudentSortedreaddToEnd(){
		SortedLinkedList basic = new SortedLinkedList(Comparator.naturalOrder());
		basic.addToFront(3);
		basic.addToFront(2);
		basic.addToFront(1);
		basic.add(5);
		basic.add(1);
		basic.addToEnd(2);
		String crr = basic.toString();
		String test = "\" 2 3 5 \"";
		Assert.assertEquals(test, crr);
	}

	@Test
	public void StudentSortedaddToFront(){
		SortedLinkedList basic = new SortedLinkedList(Comparator.naturalOrder());
		basic.addToFront(3);
		basic.addToFront(2);
		basic.addToFront(1);
		basic.add(5);
		basic.add(1);
		basic.addToEnd(2);
		String crr = basic.toString();
		String test = "\" 2 3 5 \"";
		Assert.assertEquals(test, crr);
	}

	@Test
	public void Student(){
		// 1 2  3   
		/*  permutations is where order matters 
		              f(1 2 3)
		       i=0     f()    
		       i= 1   f()      f(2)
		       i = 2 f() f(3) f(2) f(2 3)

		 */
		/*  []
		 *   1
		 *   1 2
		 *   1 2 3
		 *   2
		 *   2 3
		 *   3
		 *   3 1 2
		 *   3 2 1
		 *   2 1 3
		 *   2 3 1
		 *   null
		 *   
		 *   2 2  2  2
		 *   
		 */
		BasicLinkedList  basic = new BasicLinkedList<Object>();
		SortedLinkedList sortedList = new SortedLinkedList(Comparator.naturalOrder());
		//basic.addToFront();
		basic.retrieveFirstElement();
		

		//basic.remove(1);
		System.out.print(basic.toString());
		Assert.assertEquals("", "");
	}
	
	@Test
	public void BasicSortedLinkedlistEmpty(){
		SortedLinkedList sortedList = new SortedLinkedList(Comparator.naturalOrder());
		sortedList =sortedList.remove(4);
		String answ = sortedList.toString();
		Assert.assertEquals("\" \"", answ);
	}
	
	@Test
	public void SortedLinkedlistRemoveOne(){
		SortedLinkedList sortedList = new SortedLinkedList(Comparator.naturalOrder());
		//sortedList.add(4);
		//sortedList.add(5);
		//sortedList.add(7);
		sortedList = sortedList.remove(4);
		String answ = sortedList.toString();
		Assert.assertEquals("\" \"", answ);
	}
	
	
	@Test
	public void BasicAddListRetrieveList(){
		
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(1);
		basic.addToEnd(2);
		String crr = basic.toString();
		Assert.assertEquals("\" 1 2 \"", crr);	
		basic.retrieveLastElement();
	
		crr = basic.toString();
		Assert.assertEquals("\" 1 \"", crr);
		basic.retrieveFirstElement();
		crr = basic.toString();
		Assert.assertEquals("\" \"", crr);
		basic.addToEnd(-1);
		basic.addToFront(2);
		String basicCrr = basic.toString();
		Assert.assertEquals("\"2 -1\"", crr);
		
	}
	
	@Test
	public void BasicIterator(){
		BasicLinkedList basic = new BasicLinkedList();
		basic.addToFront(1);
		basic.addToEnd(2);
		String crr = "";
		Iterator it = basic.iterator();
		while(it.hasNext()) {
			crr  += it.next().toString() + " ";
		}
		
		Assert.assertEquals("1 2 ", crr);
		
	}
	
	@Test
	public void BasicGetFirstLast(){
		BasicLinkedList basic = new BasicLinkedList();
		//basic.addToFront(1);
		//basic.addToEnd(2);
		int firstItem = (int) basic.getFirst();
		int item = (int) basic.getLast();
		String crr = Integer.toString(item);
		String secondCrr =  Integer.toString(firstItem);
		Assert.assertEquals("2", crr);
		Assert.assertEquals("1",secondCrr);
		String basicCrr = basic.toString();
		Assert.assertEquals("\" 1 2 \"", basicCrr);
		
	}
	
	@Test
	public void size(){
		BasicLinkedList basic = new BasicLinkedList();
		//basic.addToFront(1);
		//basic.addToEnd(2);
		//basic.addToFront(13);
		//basic.addToEnd(52);
		int firstItem = (int) basic.getSize();
		Assert.assertEquals(0,firstItem);
	}
	
	@Test
	public void BasicReverseListA(){
		BasicLinkedList basic = new BasicLinkedList();
		SortedLinkedList basicSort = new SortedLinkedList(Comparator.naturalOrder());
		basic.addToFront(1);
		basic.addToEnd(2);
		basic.addToFront(3);
		basic.addToEnd(4);
		ArrayList<?> array  = basic.getReverseArrayList();
		basic = basic.getReverseList();
		basic = basic.getReverseList();
		String basicCrr = basic.toString();
		String crr = "";
		crr = array.toString();
		crr = basic.toString();
		//Assert.assertEquals("\" 4 2 1 3 \"", crr);
		Assert.assertEquals("\" 4 2 1 3 \"", basicCrr);
		basic = basic.getReverseList();
		basicCrr = basic.toString();
		Assert.assertEquals("\" 3 1 2 4 \"", basicCrr);
		
		// 3124
	}

	
	
	

}