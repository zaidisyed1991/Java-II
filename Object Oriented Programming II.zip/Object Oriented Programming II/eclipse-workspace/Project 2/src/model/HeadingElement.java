package model;

public class HeadingElement extends TagElement {
	private Element content; 
	private int level; 
	private String attributes;

	//   <h1>Introduction</h1>
	
	public HeadingElement(Element content, int level, String attributes){
		super("h" + level, true, content, decideContent(attributes));
		this.content = content;
		this.level = level;
		this.attributes = attributes;
	}
	private static String decideContent(String attributes) {
		
		if(attributes == null) {
			return "";
		} 
			return attributes;
	}
	
}
