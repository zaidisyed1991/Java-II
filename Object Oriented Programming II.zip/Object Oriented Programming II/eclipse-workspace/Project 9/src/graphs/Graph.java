package graphs;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Implements a graph. We use two maps: one map for adjacency properties 
 * (adjancencyMap) and one map (dataMap) to keep track of the data associated 
 * with a vertex. 
 * 
 * @author cmsc132
 * 
 * @param <E>
 */
public class Graph<E> {
	/* You must use the following maps in your implementation */
	private HashMap<String, HashMap<String, Integer>> adjacencyMap = new HashMap<>();
	private HashMap<String, E> dataMap = new HashMap<>();


	public void doBreadthFirstSearch(String start, CallBack<E> callBack) {
		doBreadthFirstSearchIteration(callBack, new HashSet<>(), start);
	}

	private void doBreadthFirstSearchIteration(CallBack<E> callBack, HashSet<String> visited, String... currentLevel) {
		List<String> nextLevel = new ArrayList<>();
		for(String current : currentLevel) {
			if(!visited.contains(current)) {
				callBack.processVertex(current, dataMap.get(current));
				visited.add(current);
				nextLevel.addAll(adjacencyMap.get(current).keySet());
			}
		}
		Collections.sort(nextLevel);
		if(!nextLevel.isEmpty()) {
			doBreadthFirstSearchIteration(callBack, visited, nextLevel.toArray(new String[0]));
		}
	}

	public void doDepthFirstSearch(String start, CallBack<E> printCallBack) {
		final Stack<String> entries = new Stack<>();
		final HashSet<String> visited = new HashSet<>();
		entries.push(start);
		while (!entries.empty()){
			final String current = entries.pop();
			if(!visited.contains(current)){
				visited.add(current);
				printCallBack.processVertex(current, dataMap.get(current));
				adjacencyMap.get(current).keySet().forEach(entries::push);
			}
		}
	}

	public void addVertex(String vertex, E value) {
		dataMap.put(vertex, value);
	}

	public void addDirectedEdge(String start, String end, int weight) {
		adjacencyMap.computeIfAbsent(start, (edge)-> new HashMap<>()).put(end, weight);
	}

	public Set<String> getVertices() {
		return dataMap.keySet();
	}

	@Override
	public String toString() {
		final StringBuilder stringBuilder = new StringBuilder();
		stringBuilder
			.append("Vertices: [");
		ArrayList<String> verts = new ArrayList<>(dataMap.keySet());
		Collections.sort(verts);

		stringBuilder
			.append(verts.stream().collect(Collectors.joining(",")))
			.append("]\n")
			.append("\nEdges:\n");
		for (String start : verts) {
			stringBuilder.append("Vertex(" + start + ")--->{");
			final ArrayList<String> keys = new ArrayList<>(adjacencyMap.getOrDefault(start, new HashMap<>()).keySet());
			Collections.sort(keys);
			stringBuilder.append(keys.stream().map(key -> key+"="+adjacencyMap.getOrDefault(start, new HashMap<>()).get(key)).collect(Collectors.joining(", ")));
			stringBuilder.append("}\n");
		}
		return stringBuilder.toString();
	}

	public int doDijkstras(String startVertex, String endVertex, ArrayList<String> shortestPath) {
		final HashMap<String, DistanceAndPath> tentativeDist = new HashMap<>();
		tentativeDist.put(startVertex, new DistanceAndPath(Arrays.asList(startVertex), 0));
		final Set<String> unvisited = new HashSet<>(dataMap.keySet());
		String currentNode = startVertex;
		while (!unvisited.isEmpty()){
			for(String reachable : adjacencyMap.getOrDefault(currentNode, new HashMap<>()).keySet()){
				Integer reachableDist = tentativeDist.get(currentNode).getDistance() + adjacencyMap.get(currentNode).get(reachable);
				final DistanceAndPath forNext = tentativeDist.getOrDefault(reachable, new DistanceAndPath(null, Integer.MAX_VALUE));
				if(forNext.getDistance() > reachableDist){
					final ArrayList<String> path = new ArrayList<>(tentativeDist.get(currentNode).getPath());
					path.add(reachable);
					tentativeDist.put(reachable, new DistanceAndPath(path, reachableDist));
				}
			}
			if(endVertex.equals(currentNode)
				|| tentativeDist.entrySet().stream().filter(o -> unvisited.contains(o.getKey())).allMatch(e -> e.getValue().getDistance().equals(Integer.MAX_VALUE))){
				break;
			} else {
				unvisited.remove(currentNode);
				String minUnvisitedNode = null;
				Integer minUnvistitedDist = Integer.MAX_VALUE;
				for (String node : unvisited) {
					final Integer dist = tentativeDist.getOrDefault(node, new DistanceAndPath(null, Integer.MAX_VALUE)).getDistance();
					if (dist < minUnvistitedDist) {
						minUnvisitedNode = node;
						minUnvistitedDist = dist;
					}
				}
				currentNode = minUnvisitedNode;
			}
		}
		final DistanceAndPath result = tentativeDist.getOrDefault(endVertex, new DistanceAndPath(Arrays.asList("None"), -1));
		shortestPath.addAll(result.getPath());
		return result.getDistance();
	}

	private class DistanceAndPath {

		private List<String> path;
		private Integer distance;

		public DistanceAndPath(List<String> node, Integer distance) {
			this.path = node;
			this.distance = distance;
		}

		public List<String> getPath() {
			return path;
		}

		public Integer getDistance() {
			return distance;
		}

		@Override
		public String toString() {
			return new StringJoiner(", ", DistanceAndPath.class.getSimpleName() + "[", "]")
				.add("path=" + path)
				.add("distance=" + distance)
				.toString();
		}
	}
}