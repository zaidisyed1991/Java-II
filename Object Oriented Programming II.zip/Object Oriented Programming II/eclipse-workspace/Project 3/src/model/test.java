package model;

import java.util.Arrays;

public class test {
 public static void main(String[] args) {
	 int [][] array = {{1,2,3}, { 4, 5, 6} , {7,8,9}};
	  int [][]  newArray =  new int [array.length][array[0].length];
	  
	  for( int row = 0; row < array.length-1; row++) { 
		  for(int col = 0; col < array[row].length ; col++) {
			  newArray[row][col] = array[row][col];
			  //System.out.println(newArray[row][col]);
		  }
	  }
	   // NewArray                
	  /*1,2,3},     row =0      [0] [0]  row=0 [0][1] row =0 [0] [2]
	   *{ 4, 5, 6}   row =1     rwo =1 [1][0]   row =1    [1] [1]  row =1 [1] [2]
	   *
	   * Array 
	   * {1,2,3},     row =1   row = 0    
	   * 
	   * 
	   * ***{*4*, 5,6}   row = 1   [1] [0] row =1  [1][1]  row =1[1][2]
	   *  ***7,8,9}     row = 2    [2][]0]  row =2     row=2 ........
	   *
	   */
	  for( int row = 1; row < array.length; row++) { 
		  for(int col = 0; col < array[row].length ; col++) {
		       array[row][col] = newArray[row - 1 ][col];
		  }
	  }
	  
	  
	  for(int col = 0 ; col < array.length ; col++) {
		  array[0][col] = 0;
	  }
	  
	  
	  for( int row = 0; row < array.length; row++) { 
		  //System.out.print(array[row][] + "\n");
		  for(int col = 0; col < array[row].length ; col++) {
			  System.out.println(array[row][col]);
			  
		  }
	  }
	 /*
	  *  have a for loop which begins at the 3rd row
	  */
	  
	  /* we use a for loop and start at 0 and have a check condition that is 
	   * array leght subtracted by two. increment the loop
	   * make the inner loop the same a s before.
	   * 
	   * in the body do the same thing as line 12 and 13.
	   * arr.length -2 
	   *        outer for loop   arra.length -2
	   *           inner for loop  same as line 11
	   *               newArray[row][col]  =  0
	   *         
	   *         inner for loop  same as line 11
	   *               newArray[0][col]  =  0
      */
	 /* 
	  shift down :
			 * 
			 *  copy all of  the elements excluding the last 
			 *  to the next row  
			 *  reset the first row
			 *  
	  */            
}

}