package onlineTest;

import java.io.Serializable;
import java.util.Map;

public class calculatePtsExamT implements Serializable {
	Question crrntQuestion;
	String stdName;
	public calculatePtsExamT (Question question, String stdName) {
		this.crrntQuestion = question;
		this.stdName = stdName;
	}
	
	public static double calculateExamTotal(Exam exam) {
		double totalPoints = 0;
		Map<Integer, Question> questions = exam.getQuestions();
		for(Map.Entry<Integer, Question> entry: questions.entrySet()) {
			Question question = entry.getValue();
			totalPoints += question.getPoints();
		}
		return totalPoints;
	}
	public calculatePtsExamT(){

	}
}
