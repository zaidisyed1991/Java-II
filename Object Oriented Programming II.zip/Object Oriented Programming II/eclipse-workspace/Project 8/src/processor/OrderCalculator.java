package processor;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import tests.TestingSupport;

public class OrderCalculator implements Runnable {
    private Object lock;
    private int i;
    private File file;
    private List<Client> clientList;



    public OrderCalculator(Object lockObj, int i, File file,  List<Client> clientList) {
        this.lock = lockObj;
        this.i = i;
        this.file = file;
        this.clientList = clientList;
 
    }
  
	@Override
    public void run() {
        readFiles(i, file);
    }
	

    public void readFiles(int i, File file){
        try {
            // Create a new Scanner object which will read the data
            // from the file passed in. To check if there are more
            // line to read from it we check by calling the
            // scanner.hasNextLine() method. We then read line one
            // by one till all lines is read.
            Scanner scanner = new Scanner(file);
            String clientInfo = scanner.nextLine();
            String[] id = clientInfo.split(" ");
            Client client = new Client(id[1]);
            synchronized(lock) {
            	clientList.add(client);
            }
            System.out.println("Reading order for client with id:" + id[1]);
            while (scanner.hasNextLine()) {
                //numOrders
                //if basename is "example" and the number of orders is 3, the files will be named example1.txt,
                // example2.txt, and example3.txt. Find a way to generate those
                // strings from the basename and number of orders, then use a java
                // class to read from the file with that name (such as Scanner).
                String line = scanner.nextLine();
                String[] namePrice = line.split(" ");
                Item item = new Item(namePrice[0]);
                synchronized (lock) {
                    client.setQuantItems(item);
                }

                //System.out.println("namePrice" + namePrice[0] + "namePrice" + namePrice[1]);
            }
           /* client.getQuantItems().entrySet().forEach(entry->{
                System.out.println(client.id + entry.getKey() + " " + entry.getValue());
            });*/
        } catch (FileNotFoundException e) {
            e.printStackTrace();

        }
    }

}
