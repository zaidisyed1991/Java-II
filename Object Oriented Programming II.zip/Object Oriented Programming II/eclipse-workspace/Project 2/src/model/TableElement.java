package model;

public class TableElement extends TagElement {
	private int rows;
	private int cols;
	private String attributes;
	private  Element tableElement [][];

	public TableElement(int rows, int cols, String attributes) {
		super("table",false, null, decideContent(attributes));
		this.rows = rows;
		this.cols = cols;
		this.attributes = attributes;
		tableElement = new Element [rows][cols];

	}
	private static String decideContent(String attributes) {
		
		if(attributes == null) {
			return "";
		} 
			return attributes;
	}
	

	public void addItem(int rowIndex, int colIndex, Element item) {
		tableElement[rowIndex][colIndex] = item;
	}
	public double getTableUtilization() {
		double value = 0.0;
		double count = 0.0;
		for (int row = 0; row < tableElement.length; row++) {
			for (int col = 0; col < tableElement[row].length; col++) {
				if (tableElement[row][col] != null) {
					count++;
				}
			}
		}
		value = (count / (double) (rows * cols) ) * 100;
		return value;
	}



	@Override
	public String genHTML(int indentation) {
		String result = "";
		/*
		 * 1.) Make an empty string
		 * 2.) Make a for loop who's limit goes till indentation
		 * 3.) within body concatenate string with indentation (ans += " ";
		 * 4.) outside loop concatenate string with getStart element"
		 * 5.) concatenate string with <tr><td>
		 * 6.) conatenate string with text
		 * 7.) concatenate string with closing </td><td>
		 * 
		 */


		result += super.genHTML(indentation);
		result += "\n";

		/* loop through rows
		 *   loop through columns
		 *     element E    store one element 
		 *      
		 */   
		/*
		 *    <table id="table1" border="1">
	      <tr> <td>John</td>  <td>Laura</td>  </tr>     

	      <tr> <td>Rose</td>   <td>jjj</td>     </tr>
	   </table>
		 * 
		 */

 		Element e;
		for (int row = 0; row < tableElement.length; row++) {
			for (int i = 0; i < indentation * 2; i++) {
				result+= " ";
			}
			result += "<tr>";
			for (int col = 0; col < tableElement[row].length; col++) {				
				result += "<td>";
				e = tableElement[row][col];
				if(e!= null) {
					result += e.genHTML(0);
				} else { 
					result += "";
				}
				result += "</td>";
			}
			result += "</tr>";
			result += "\n";
		}
		for (int i = 0; i < indentation; i++) {
			result+= " ";
		}
		result += super.getEndTag();
		return result;
	}
	//[john    ]
	//[    ben  ]



}
