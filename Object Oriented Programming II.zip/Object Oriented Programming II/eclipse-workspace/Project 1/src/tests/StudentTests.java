package tests;
import static org.junit.Assert.*;
import org.junit.Test;


/**
 * Please put your own test cases into this file, so they can be tested
 * on the server.
*/

public class StudentTests {
	
}