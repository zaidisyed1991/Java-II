package listClasses;

import java.util.Comparator;

public class SortedLinkedList<T>  extends BasicLinkedList<T>{
    Comparator<T> comparator = null;
    public SortedLinkedList(Comparator<T> comparator){
        super();
        this.comparator = comparator;
    }

    public SortedLinkedList<T> add(T element) {
        // 1- 2 -3 -4      1-2-3-4 5 [6]     2   [1]
        // do this for each element in list
        // while going thorugh
        // if the element fast is less than it point slow.next to it  point elemnt.next to fast.next;
        //move slow and fast
        //  if the element is less than the head value point its  new elemnt.next  and new head
        //if youve reached the end and you havent added then point tail.next to new element and make it tial
        Node ptr = head;
        Node newElement = new Node(element);
        if( head == null){
            head = newElement;
            size++;
            tail = head;
            return this;
        }

        T headValue = (T) head.data;
        Node fast = head;
        Node slow = null;
        int compHeadValue = comparator.compare(element, headValue);

        int compMiddleValue = 0;
        if (compHeadValue <= 0) {
            newElement.next = head;
            head = newElement;
            size++;
            return this;
        }

        while (fast != null && fast.next != null) {
            slow = fast;
            fast = fast.next;
            if(fast !=null) {
                compMiddleValue = comparator.compare(element, (T) fast.data);
            }
            if (compMiddleValue <= 0) {
                slow.next = newElement;
                newElement.next = fast;
                size++;
                return this;
            }

        }

        tail.next = newElement;
        tail = newElement;
        size++;

        return this;
    }

    public SortedLinkedList<T> remove(T targetData){
        super.remove(targetData, this.comparator);
        return this;
    }

    public BasicLinkedList<T> addToEnd(T data){
        throw new UnsupportedOperationException();
    }

    public BasicLinkedList<T> addToFront(T data){
        throw new UnsupportedOperationException();
    }
}