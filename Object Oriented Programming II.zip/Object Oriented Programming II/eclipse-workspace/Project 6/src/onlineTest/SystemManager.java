package onlineTest;

import static org.junit.Assert.assertTrue;

import java.io.*;
import java.util.*;

import org.junit.Test;

import tests.TestingSupport;

public class SystemManager implements Manager {

	public static void main(String[]args) {
		StringBuffer answer = new StringBuffer();
		SystemManager manager = new SystemManager();

		manager.addExam(1, "Midterm #1");
		manager.addTrueFalseQuestion(1, 1, "Abstract classes cannot have constructors.", 35, false);
		manager.addTrueFalseQuestion(1, 2, "The equals method returns a boolean.", 15, true);
		manager.addTrueFalseQuestion(1, 3, "The hashCode method returns an int", 50, true);

		String studentName = "Peterson,Laura";
		manager.addStudent(studentName);
		manager.answerTrueFalseQuestion(studentName, 1, 1, true);
		manager.answerTrueFalseQuestion(studentName, 1, 2, true);
		manager.answerTrueFalseQuestion(studentName, 1, 3, true);

		studentName = "Cortes,Laura";
		manager.addStudent(studentName);
		manager.answerTrueFalseQuestion(studentName, 1, 1, false);
		manager.answerTrueFalseQuestion(studentName, 1, 2, true);
		manager.answerTrueFalseQuestion(studentName, 1, 3, true);
		/*
		 * when you add an exam
		 * create a new instance of
		 * an exam object;
		 *
		 *
		 */
		studentName = "Sanders,Tom";
		manager.addStudent(studentName);
		manager.answerTrueFalseQuestion(studentName, 1, 1, true);
		manager.answerTrueFalseQuestion(studentName, 1, 2, false);
		manager.answerTrueFalseQuestion(studentName, 1, 3, false);

		manager.setLetterGradesCutoffs(new String[]{"A","B","C","D","F"},
				new double[] {90,80,70,60,0});

		answer.append(manager.getCourseGrades());
		System.out.println(answer);
	}





	Set <String> students;
	Map<Integer, Exam> exams;
	Map<String, List<Exam>> mapStudentExams;
	Map<Double, String> mapCutoffs;
	public SystemManager() {
		exams = new HashMap<>();
		mapStudentExams = new HashMap<>();
		students = new TreeSet<>();
		mapCutoffs = new HashMap<>();
	}

	private Set getStudents() {
		return this.students;
	}

	@Override
	public boolean addExam(int examId, String title) {
		/*
		 * put in database
		 */
		Exam newExam = new Exam(title, examId);
		if(!exams.containsKey(examId)) {
			exams.put(examId, newExam );
			return true;
		}
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void addTrueFalseQuestion(int examId, int questionNumber, String text, double points, boolean answer) {
		// TODO Auto-generated method stub
		QuestType TF = QuestType.TF; 
		Question TFQuestion = new Question(answer, points , questionNumber, text, TF);
		Exam newExam = exams.get(examId);
		newExam.setQuestions(TFQuestion);
		exams.put(examId, newExam);


	}

	@Override
	public void addMultipleChoiceQuestion(int examId, int questionNumber, String text, double points, String[] answer) {
		// Adds a multiple choice question to the specified exam. If the question already exists it is overwritten.
		//Create a question object and pass in questionNumber, text points, answer
		//Make an exam object
		//Add the question to the exam
		QuestType MC = QuestType.MC; 
		Question MCQuestion = new Question(answer, points, questionNumber, text, MC);
		Exam e1 = exams.get(examId);
		e1.setQuestions(MCQuestion);
		exams.put(examId, e1);

	}

	@Override
	public void addFillInTheBlanksQuestion(int examId, int questionNumber, String text, double points,
			String[] answer) {
		// TODO Auto-generated method stub
		QuestType FB = QuestType.FB; 
		Question FBQuestion = new Question(answer, points, questionNumber, text, FB);
		Exam e1 = exams.get(examId);
		e1.setQuestions(FBQuestion);
		exams.put(examId, e1);

	}

	@Override
	public String getKey(int examId) {
		// TODO Auto-generated method stub

		String result = "";
		Exam e1 = exams.get(examId);
		Map<Integer, Question> allQ = e1.getQuestions();
		String correctAnsw = "";
		for(Map.Entry<Integer, Question> entry: allQ.entrySet()){
			correctAnsw = " ";
			Question question = entry.getValue();
			String crrTxt = question.getText();
			double points = question.getPoints();
			QuestType type = question.getTyp();
			if( type == (QuestType.TF)) {
				/*
				 * hello
				 * char a = s.chart(0) = h
				 * s.indexOF(h) = 0
				 * Strings are immutable.  
				 * {H,e,l,l,0} = String
				 * 
				 */

				String crrntS = String.valueOf((boolean)question.getAnswer());
				char[] strArray = crrntS.toCharArray();
				strArray[0] = Character.toUpperCase(strArray[0]);
				String tfString = new String(strArray);
				correctAnsw += tfString;
			} else if(type == (QuestType.MC)){
				String[] mcQAnswer = (String []) question.getAnswer();
				Arrays.sort(mcQAnswer);
				correctAnsw += Arrays.toString(mcQAnswer);
			} else {
				String[] fbQAnswer = (String []) question.getAnswer();
				Arrays.sort(fbQAnswer);
				correctAnsw += Arrays.toString(fbQAnswer);
			}
			result += "Question Text: " + crrTxt + "\n";
			result += "Points: " + points + "\n";
			result+= "Correct Answer:" + correctAnsw + "\n";


		}
		return result;
	}

	@Override
	public boolean addStudent(String name) {
		// TODO Auto-generated method stub]
		for(String student: students) {
			if(student.contentEquals(name)) {
				return false;
			}
		}

		students.add(name);
		return true;
	}

	private void setExam(String studName, Exam exam) {
 
	
		List<Exam> blank = new ArrayList<>();

		List<Exam> examPlusOne = mapStudentExams.getOrDefault(studName, blank);
		for(Exam exams: examPlusOne) {
			if(exams == exam) {
				return;
			}
		}
		
		examPlusOne.add(exam);
		List<Exam> newExams = examPlusOne;
		mapStudentExams.put(studName, newExams);
	}

	private Exam getExam(int examId) {
		for(Map.Entry<String, List<Exam>> entry:  mapStudentExams.entrySet()) {
			List<Exam> exams = entry.getValue();
			for(Exam exam: exams) {
				if(exam.getId() == examId) return exam; 
			}
		}

		return null;
	}
	@Override
	public void answerTrueFalseQuestion(String studentName, int examId, int questionNumber, boolean answer) {
		// TODO Auto-generated method stub
		/*
		 *  create exam
		 *  put in the map the student, exam
		 */
		Exam newExam = exams.get(examId);
		Question oneQuesiton = newExam.getOneQuetion(questionNumber);
		oneQuesiton.setStudAnswer(answer, studentName);
		setExam(studentName, newExam);
		updateStudPoints(studentName, examId, newExam, oneQuesiton);

		//onlineTest.Question@131276c2

	}

	@Override
	public void answerMultipleChoiceQuestion(String studentName, int examId, int questionNumber, String[] answer) {
		// TODO Auto-generated method stub
		Exam newExam = exams.get(examId);
		Question oneQuesiton = newExam.getOneQuetion(questionNumber);
		
		oneQuesiton.setStudAnswer(answer, studentName);
		setExam(studentName, newExam);
		updateStudPoints(studentName, examId, newExam, oneQuesiton);


	}

	@Override
	public void answerFillInTheBlanksQuestion(String studentName, int examId, int questionNumber, String[] answer) {
		// TODO Auto-generated method stub
		Exam newExam = exams.get(examId);
		Question oneQuesiton = newExam.getOneQuetion(questionNumber);
		oneQuesiton.setStudAnswer(answer, studentName);
		setExam(studentName, newExam);
		updateStudPoints(studentName, examId, newExam, oneQuesiton);

	}

	@Override
	public double getExamScore(String studentName, int examId) {
		// TODO Auto-generated method stub

		String result = "";
		Exam crrntExam = getExam(examId);
		double answ = crrntExam.getAccStudPts(studentName);

		return answ;
	}

	@Override
	public String getGradingReport(String studentName, int examId) {
		// TODO Auto-generated method stub
	

		String result = "";
		Exam crrntExam = getExam(examId);
		double totalStudent = 0;
		double totalPoints = 0;
		Map<Integer,Question> questions = crrntExam.getQuestions();
		for(Map.Entry<Integer, Question>entry:questions.entrySet()) {
			Question oneQuest = entry.getValue();
			calculatePtsOfT calcPoints = new calculatePtsOfT(oneQuest, studentName);
			double pointsStudent = calcPoints.calculate();
			double pointsforQues = oneQuest.getPoints();
			result += "Question # " + oneQuest.getQuestionNumber() +" " +  pointsStudent + " " ;
			result += "points out of ";
			result += pointsforQues;
			totalStudent += pointsStudent;
			totalPoints += pointsforQues;
			result += "\n";	    
		}
		result += "Final Score: " + totalStudent +  " out of ";
		result += totalPoints;


		return result;
	}

	@Override
	public void setLetterGradesCutoffs(String[] letterGrades, double[] cutoffs) {
		// TODO Auto-generated method stub
		for (int i = 0; i < letterGrades.length; i++) {
			mapCutoffs.put(cutoffs[i], letterGrades[i]);
		}

	}

	private static void updateStudPoints(String studentName, int examId, Exam crrntExam, Question crrQuestion){
		calculatePtsOfT calcPoints = new calculatePtsOfT(crrQuestion, studentName);
		double pointsStudent = calcPoints.calculate();
		crrntExam.setAccStudPts(pointsStudent, studentName);
	}

	@Override
	public double getCourseNumericGrade(String studentName) {
		// TODO Auto-generated method stub
	
		double totalPoints = 0;
		double studentPoints = 0;
		double totalNum = 0;
		List<Exam> exams = mapStudentExams.get(studentName);
		calculatePtsOfT calculator = new calculatePtsOfT();
		calculatePtsExamT examClaculator = new calculatePtsExamT();
		Exam crrntExam = null;
		for(Exam exam: exams){
			crrntExam = getExam(exam.getId());
			totalPoints  = examClaculator.calculateExamTotal(exam);
			studentPoints = getExamScore(studentName, exam.getId());
			totalNum += (studentPoints / totalPoints) * 100;
			// exam 1 : 14, exam2: 22  exm 3 18  
		}
		

		return totalNum / exams.size();
	}

	@Override
	public String getCourseLetterGrade(String studentName) {
		// TODO Auto-generated method stub
		double numberG = getCourseNumericGrade(studentName);
		/*
		 * go to hashmap
		 * get the corresponding rade
		 * 
		 */
		if(numberG >= 90.0) {
			numberG = 90.0;
		} else if(numberG < 90 && numberG >= 80) {
			numberG = 80.0;
		} else if(numberG < 80 && numberG >= 70) {
			numberG = 70.0;
		} else if(numberG < 70 && numberG >= 60) {
			numberG = 60.0;
		} else {
			numberG = 0.0;
		}
		String letterG = mapCutoffs.get(numberG);
		return letterG;
	}

	@Override
	public String getCourseGrades() {
		// TODO Auto-generated method stub
		String result = "";
		String letterG = " ";
		for(String student: students) {
			double numG = getCourseNumericGrade(student); 
			letterG = getCourseLetterGrade(student);
			result += student;
			result += " " + numG + " " + letterG + "\n";
		}
		

		
		return result;
	}

	@Override
	public double getMaxScore(int examId) {
		PriorityQueue<Double> maxScores = new PriorityQueue<Double>(Collections.reverseOrder());
		double studPoints = 0;
		for(String student: students){
			//get the maximum
			studPoints = getExamScore(student, examId);
			maxScores.add(studPoints);
		}

		return maxScores.peek();
		// TODO Auto-generated method stub
	}

	@Override
	public double getMinScore(int examId) {
		PriorityQueue<Double> minScores = new PriorityQueue<Double>();
		double studPoints = 0;
		for(String student: students){
			//get the maximum
			studPoints = getExamScore(student, examId);
			minScores.add(studPoints);
		}
		// TODO Auto-generated method stub
		return minScores.peek();
	}

	@Override
	public double getAverageScore(int examId) {
		// TODO Auto-generated method stub
		double totalScores = 0;
		double size = 0;
		for(String student: students){
			totalScores += getExamScore(student, examId);
			size++;
		}

		return totalScores / size;
	}

	@Override
	public void saveManager(Manager manager, String fileName) {
		// TODO Auto-generated method stu
		File newFile = new File(fileName);
		try {
			ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(newFile));
			output.writeObject(manager);
			output.close();
		}catch (Exception e){
			e.printStackTrace();
		}


	}

	@Override
	public Manager restoreManager(String fileName) {
		// TODO Auto-generated method stub
		File file = new File(fileName);
		try {
			ObjectInputStream input = new ObjectInputStream(new FileInputStream(file));
			Manager manager = (Manager) input.readObject();
			input.close();

			return manager;
		} catch (Exception e){
			e.printStackTrace();
		}

		return null;
	}

}
