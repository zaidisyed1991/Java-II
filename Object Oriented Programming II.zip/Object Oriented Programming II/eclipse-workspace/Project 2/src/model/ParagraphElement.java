package model;

import java.util.ArrayList;

public class ParagraphElement extends TagElement {
    private String attributes;
    private ArrayList<Element> paragraphElement;

    public ParagraphElement(String attributes) {
        super("p",false, null, decideContent(attributes));
        this.attributes = attributes;
        paragraphElement = new ArrayList<Element>();
    }
    public void addItem(Element item) {
        paragraphElement.add(item);
    }
    private static String decideContent(String attributes) {

        if(attributes == null) {
            return "";
        }
        return attributes;
    }
    public String genHTML(int indentation) {
        String result = "";
        Element e;
        result += super.genHTML(indentation);
        result += "\n";
        for (int i = 0; i < paragraphElement.size(); i++) {
            result += indent(indentation);
            e = paragraphElement.get(i);
            result += e.genHTML(indentation);
            result += "\n";
        }
        result += indent(indentation);
        result += super.getEndTag();
        return result;
    }

    /* <p id="p1">
     * <h1>Introduction</h1>
     *
     */




    //	   <p id="p1">
    //	      Fear the turtle
    //	      <img id="img2" src="testudo.jpg" width="84" height="111" alt="Testudo Image">
    //	      <a id="a3" href="http://www.cs.umd.edu">UMD</a>
    //	   </p>
    //	SecondElement
    //	      <p style="color:red">
    //	         Fear the turtle
    //	         <img src="testudo.jpg" width="84" height="111" alt="Testudo Image">
    //	      </p>
    //
    //	EndTest
    private String indent(int indentation) {
        String result = "";
        for (int j = 0; j < indentation; j++) {
            result+= " ";
        }
        return result;
    }

}
