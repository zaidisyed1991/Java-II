package tests;

import static org.junit.Assert.*;

import model.*;
import org.junit.Assert;
import org.junit.Test;

public class StudentTests {

	@Test
	public void publicWeb4(){
		WebPage webPage = new WebPage("OAC Testfile - Check #174 - Negative");
		int indentation = 3;
		String headingAttributes = null;
		String paragraphAttributes = null;
		String answer = "";
		TagElement.resetIds();
		TagElement.enableId(false);
		ParagraphElement paragraph = new ParagraphElement((String)paragraphAttributes);
		paragraph.addItem(new TextElement("Select link for more information about dogs."));
		paragraph.addItem(new AnchorElement("dogs.html","hello",null));
		webPage.addElement(paragraph);
		answer = answer + webPage.getWebPageHTML(indentation);
		answer = answer + "\nEndTest";
		Assert.assertTrue(TestsSupport.isCorrect("pubWebPageTest4.txt", answer));
	}

	@Test
	public void publicWeb5(){
		WebPage webPage = new WebPage("OAC Testfile - Check #46 - Positive");
		int indentation = 3;
		String headingAttributes = null;
		String paragraphAttributes = null;
		String answer = "";
		TagElement.resetIds();
		TagElement.enableId(false);
		ParagraphElement paragraph = new ParagraphElement((String)paragraphAttributes);
		paragraph.addItem(new TextElement("This is"));
		webPage.addElement(paragraph);
		HeadingElement header = new HeadingElement(new TextElement("very important"),5, null);
		webPage.addElement(header);
		ParagraphElement secparagraph = new ParagraphElement((String)paragraphAttributes);
		secparagraph.addItem(new TextElement("and you should read it."));
		webPage.addElement(secparagraph);
		answer = answer + webPage.getWebPageHTML(indentation);
		answer = answer + "\nEndTest";
		Assert.assertTrue(TestsSupport.isCorrect("pubWebPageTest5.txt", answer));

	}

	@Test
	public void pubWebPageTest6() {
		WebPage webPage = new WebPage("Example9");
		int indentation = 3;
		String answer = "";
		TagElement.resetIds();
		TagElement.enableId(false);
		TableElement tableElement;
		tableElement = new TableElement(3, 3, (String)null);
		tableElement.addItem(0, 0, new TextElement("Red"));
		tableElement.addItem(0, 1, new TextElement("Blue"));
		tableElement.addItem(1, 0, new TextElement("Green"));
		tableElement.addItem(1, 1, new TextElement("Yellow"));
		webPage.addElement(tableElement);
		webPage.addElement(new ListElement(true, (String)null));
		answer = answer + webPage.getWebPageHTML(indentation);
		answer = answer + "\n" + webPage.stats();
		answer = answer + "\n\nEndTest";

}
	
}