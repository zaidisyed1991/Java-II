package tests;

import model.BoardCell;
import model.ClearCellGame;
import model.Game;
import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.assertTrue;

public class StudentTests {
    /*
      one col  4 row

      one row 4 col



     */
	@Test
	public void simple() {
		int maxRows = 1, maxCols = 1, strategy = 1;
		Game ccGame = new ClearCellGame(maxRows, maxCols, new Random(1L),
				strategy);
		ccGame.setRowWithColor(0, BoardCell.RED);
		String answer = getBoardStr(ccGame);
		
		assertTrue(TestsSupport.isCorrect("studEdg2.txt", answer));
	}
    @Test
    public void horizontalCells() {
       
    	int maxRows = 5, maxCols = 8, strategy = 1;
        Game ccGame = new ClearCellGame(maxRows, maxCols, new Random(1L), strategy);
 
        ccGame.setRowWithColor(0, BoardCell.YELLOW);
        ccGame.setBoardCell(0, 0, BoardCell.RED);
    	//ccGame.setRowWithColor(1, BoardCell.RED);
    	ccGame.setRowWithColor(2, BoardCell.YELLOW);
        ccGame.setBoardCell(5, 7, BoardCell.RED);
    
    	 
    	  //ccGame.setBoardCell(0, maxCols-1, BoardCell.RED);
    	  ccGame.processCell(0, 2);
    	  String answer = "";
    	  answer+=  getBoardStr(ccGame);
    	  	System.out.println(answer);
    	  assertTrue(TestsSupport.isCorrect("studEdg2.txt", answer));
    	/*
    	int maxRows = 1, maxCols = 3, strategy = 1;
        Game ccGame = new ClearCellGame(maxRows, maxCols, new Random(1L), strategy);

        ccGame.setBoardWithColor(BoardCell.BLUE);
        //ccGame.setRowWithColor(maxRows - 1, BoardCell.EMPTY);
        //ccGame.setRowWithColor(1, BoardCell.YELLOW);
        ccGame.setBoardCell(0, maxCols - 1, BoardCell.RED);

        String answer = "Before processCell\n\n";
        answer += getBoardStr(ccGame);
        ccGame.processCell(0, 0);
        answer += "\nAfter processCell\n";
        answer += getBoardStr(ccGame);
        //ccGame.processCell(0, maxCols - 1);
        answer += getBoardStr(ccGame);
        System.out.println("this is answer");
        System.out.println(answer);


        assertTrue(TestsSupport.isCorrect("studEdge2.txt", answer));
        */
        
        //process empty board at the top when something is udner it
        //2 you process a board  with  something in middle of it going vertical
    }
   /* 
    @Test
    public void edge1() {
    	
        int maxRows = 1, maxCols = 10, strategy = 1;
        Game ccGame = new ClearCellGame(maxRows, maxCols, new Random(1L), strategy);
        ccGame.setBoardCell(0, 0, BoardCell.RED);
        ccGame.setBoardCell(0,2 , BoardCell.YELLOW);
        ccGame.setBoardCell(0,3 , BoardCell.RED);
        ccGame.setBoardCell(0,4 , BoardCell.YELLOW);
        
        ccGame.setBoardCell(0, 5, BoardCell.RED);
        ccGame.setBoardCell(0,6, BoardCell.YELLOW);
        ccGame.setBoardCell(0,7 , BoardCell.RED);
        ccGame.setBoardCell(0,8 , BoardCell.YELLOW);
        
        ccGame.setBoardCell(0, 5, BoardCell.RED);
        ccGame.setBoardCell(0,6, BoardCell.YELLOW);
        
        String answer = "Before processCell\n\n";
        answer += getBoardStr(ccGame);
        ccGame.processCell(0, 4);
        answer += "\nAfter processCell\n";
        answer += getBoardStr(ccGame);
        System.out.println(answer);
        
    	
    }
    */



    /* Support methods */
    private static String getBoardStr(Game game) {
        int maxRows = game.getMaxRows(), maxCols = game.getMaxCols();

        String answer = "Board(Rows: " + maxRows + ", Columns: " + maxCols + ")\n";
        for (int row = 0; row < maxRows; row++) {
            for (int col = 0; col < maxCols; col++) {
                answer += game.getBoardCell(row, col).getName();
            }
            answer += "\n";
        }

        return answer;
    }



}
