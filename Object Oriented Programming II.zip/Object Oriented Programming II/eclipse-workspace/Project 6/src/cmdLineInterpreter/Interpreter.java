package cmdLineInterpreter;
import java.util.Scanner;

import onlineTest.SystemManager;
/**
 * 
 * By running the main method of this class we will be able to
 * execute commands associated with the SystemManager.  This command
 * interpreter is text based. 
 *
 */
public class Interpreter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to the Interperter.");
		System.out.println("Please choose from one of the following options.");
		System.out.println("(1) press 1 to add a Student.");
		System.out.println("(2) press 2 to add an Exam.");
		System.out.println("(3) press 3 to add True or False question");
		System.out.println("(4) press 4 to answer a True or Flase question.");
		System.out.println("(5) press 5 to get the exam score for a student.");
		System.out.println("(6) press 6 to quit.");
		Boolean done = false;
		Scanner k = new Scanner(System.in);
		int choice = 0;
		SystemManager manager =  new SystemManager();
		
		while(!done) {
			choice = k.nextInt();

			switch(choice) {
				case 1:
					System.out.println("what is the name of the student?");
					String studentName = k.next();
					manager.addStudent(studentName);
					break;
				case 2:
					System.out.println("what is the exam id?");
					int examId = k.nextInt();
					System.out.println("what is the exam title?");
					String title = k.next();
					manager.addExam(examId, title);
					break;
					
				case 3:
					System.out.println("what is the exam id?");
					int id = k.nextInt();
					System.out.println("what is the questionNumbe?");
					int questNumber = k.nextInt();
					System.out.println("what is your text?");
					String text = k.next();
					System.out.println("How many points?");
					double points = k.nextDouble();
					System.out.println("True or false?");
					boolean answer = k.nextBoolean();
					manager.addTrueFalseQuestion(id, questNumber, text, points, answer);
					break;
					
				case 4:
					System.out.println("what is the StudentName");
					String stdName = k.next();
					System.out.println("what is the exam id?");
					int idForExam = k.nextInt();
					System.out.println("what is the questionNumber?");
					int qtNumber = k.nextInt();
					System.out.println("True or false?");
					boolean booleanAnswer = k.nextBoolean();
					manager.answerTrueFalseQuestion(stdName, idForExam, qtNumber, booleanAnswer);
					break;
					
				case 5:
					System.out.println("what is the StudentName");
					String sName = k.next();
					System.out.println("what is the exam id?");
					int exmId = k.nextInt();
					System.out.println(manager.getExamScore(sName, exmId));
					break;
					
				case 6:
					done = true;
					break;
					
					
			}
			
			System.out.println("(1) press 1 to add a Student.");
			System.out.println("(2) press 2 to add an Exam.");
			System.out.println("(3) press 3 to add True or False question");
			System.out.println("(4) press 4 to answer a True or Flase question.");
			System.out.println("(5) press 5 to get the exam score for a student.");
			System.out.println("(6) press 6 to quit.");
			k.nextLine();
		
		}
		

	}
}
