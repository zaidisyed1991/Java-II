package onlineTest;

enum QuestType {
	MC("MC"), FB("FB"),TF("TF");
	
	
	QuestType(String qType){
		this.qType = qType;
	}
	public String getqType() {
		return qType;
	}
	public void setqType(String qType) {
		this.qType = qType;
	}
	private String qType;

	
}
