package processor;

import java.util.Scanner;

public class OrdersProcessor {
	
	public static void main(String[] args) {
		System.out.println("Welcome to Order Processor");
		System.out.println("Enter item's data file name:");
		Scanner k = new Scanner(System.in);
		String fileName = k.next();
		System.out.println("Enter 'y' for multiple threads, any other character otherwise: ");
		String threadCount = k.next();
		System.out.println("Enter number of orders to process");
		int numOrders = k.nextInt();
		System.out.println("Enter order's base filename:");
		String baseFileName = k.next();
		System.out.println("Enter result's filename:");
		String resultFileName = k.next();
		OrderManager manager = new OrderManager(fileName, threadCount, numOrders, baseFileName, resultFileName);
		manager.processOrderItemData();
		long startTime = System.currentTimeMillis();
		manager.processOrderBaseData();
		long endTime = System.currentTimeMillis();
		System.out.println("Processing time (msec): " + (endTime - startTime));
		k.close();
		//Why do that? How about you loop through the runnable objects tha
		// t you were going to use to make your threads anyway and just objectName.run() ?
		
	}

}
