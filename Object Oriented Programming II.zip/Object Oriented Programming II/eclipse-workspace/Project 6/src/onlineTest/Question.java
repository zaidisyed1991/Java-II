package onlineTest;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Question<T> implements Serializable {
	/*
	 * make an enum
	 */
	private Map<String, T> studAnswers;
	QuestType typ;
	private T correctAnswer;
	private double points;
	private String text;
	private int questionNumber;
	public Question(T answer, double points, int questionNumber, String text, QuestType typ) {
		this.correctAnswer = answer;
		this.points = points;
		this.questionNumber = questionNumber;
		this.text = text;
		this.typ = typ;
		studAnswers = new HashMap<>();
	}
	public T getAnswer() {
		return correctAnswer;
	}
	public void setAnswer(T answer) {
		this.correctAnswer = answer;
	}
	public double getPoints() {
		return points;
	}
	public void setPoints(double points) {
		this.points = points;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getQuestionNumber() {
		return questionNumber;
	}
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}
	
	
	public QuestType getTyp() {
		return typ;
	}
	public void setTyp(QuestType typ) {
		this.typ = typ;
	}
	public T getStudAnswer(String studName) {
		return studAnswers.get(studName);
	}
	public void setStudAnswer(T studAnswer, String studName) {
		this.studAnswers.put(studName, studAnswer);
	}
}
